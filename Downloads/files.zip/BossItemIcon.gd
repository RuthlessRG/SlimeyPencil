extends Control

# ============================================================
#  BossItemIcon.gd — draws an item icon inside a slot Control
#  Set item_data before adding to scene tree.
#  mouse_filter should be MOUSE_FILTER_IGNORE so clicks pass
#  through to the parent slot Panel.
# ============================================================

var item_data : Dictionary = {}
var _t        : float      = 0.0

func _process(delta: float) -> void:
	# Animate if gold (glow pulse) OR equipped (equip glow)
	if item_data.get("rarity", "") == "gold" or item_data.get("equipped", false):
		_t += delta
		queue_redraw()

func _draw() -> void:
	if item_data.is_empty():
		return
	match item_data.get("type", ""):
		"knife": _draw_knife()
		"rifle": _draw_rifle()

func _draw_rifle() -> void:
	# Rifle drawn horizontally: stock (left) → grip → receiver → barrel (right)
	# Icon is ~52×52. We'll work in a local coordinate space centered on the slot.
	var cx = size.x * 0.5
	var cy = size.y * 0.5

	# Silver palette — layered for depth
	var silver_dark   = Color(0.42, 0.44, 0.48)
	var silver_mid    = Color(0.62, 0.64, 0.68)
	var silver_light  = Color(0.82, 0.84, 0.88)
	var silver_shine  = Color(0.96, 0.97, 1.00)
	var scope_dark    = Color(0.28, 0.30, 0.34)
	var scope_lens    = Color(0.30, 0.65, 0.90, 0.85)
	var accent        = Color(0.55, 0.78, 1.00)   # subtle blue hi-tech accent

	# ── Equipped / gold glow (reuse same pulse logic as knife) ─
	if item_data.get("equipped", false):
		var eq_a = 0.35 + sin(_t * 4.0) * 0.18
		draw_circle(Vector2(cx, cy), 22.0, Color(accent.r, accent.g, accent.b, eq_a * 0.18))
		draw_circle(Vector2(cx, cy), 14.0, Color(accent.r, accent.g, accent.b, eq_a * 0.30))

	# Layout constants (all relative to center)
	# Rifle spans roughly x: cx-20 … cx+22, y: cy-4 … cy+4
	var stock_x   = cx - 20.0   # leftmost point (stock butt)
	var grip_x    = cx - 10.0   # where grip starts
	var recv_x    = cx -  2.0   # receiver / mag area
	var brl_start = cx +  4.0   # barrel begins
	var brl_end   = cx + 22.0   # muzzle tip
	var body_top  = cy -  4.0
	var body_bot  = cy +  4.0
	var body_mid  = cy

	# ── Stock (tapered rear end) ───────────────────────────────
	var stock_pts = PackedVector2Array([
		Vector2(stock_x,        cy - 1.5),   # butt top
		Vector2(stock_x,        cy + 1.5),   # butt bottom
		Vector2(grip_x,         body_bot),   # lower rear of receiver
		Vector2(grip_x,         body_top),   # upper rear of receiver
	])
	draw_colored_polygon(stock_pts, silver_dark)
	# Stock cheekrest ridge (top highlight)
	draw_line(Vector2(stock_x, cy - 1.5), Vector2(grip_x, body_top), silver_mid, 1.0)

	# ── Receiver / body ───────────────────────────────────────
	var recv_pts = PackedVector2Array([
		Vector2(grip_x,   body_top),
		Vector2(brl_start, body_top),
		Vector2(brl_start, body_bot),
		Vector2(grip_x,   body_bot),
	])
	draw_colored_polygon(recv_pts, silver_mid)
	# Top rail (flat-top receiver rail — iconic sci-fi detail)
	draw_line(Vector2(grip_x, body_top), Vector2(brl_start, body_top), silver_shine, 1.5)
	# Rail serration notches
	for i in 4:
		var nx = grip_x + 2.0 + i * 3.0
		draw_line(Vector2(nx, body_top - 0.5), Vector2(nx, body_top + 1.5), silver_dark, 0.8)
	# Side panel detail line
	draw_line(Vector2(grip_x + 1.0, body_mid), Vector2(brl_start - 1.0, body_mid), silver_dark, 0.8)

	# ── Pistol grip (drops below body) ────────────────────────
	var grip_cx  = grip_x + 3.5
	var grip_pts = PackedVector2Array([
		Vector2(grip_cx - 2.0, body_bot),
		Vector2(grip_cx + 2.0, body_bot),
		Vector2(grip_cx + 1.5, body_bot + 6.5),
		Vector2(grip_cx - 1.5, body_bot + 6.5),
	])
	draw_colored_polygon(grip_pts, silver_dark)
	# Grip texture lines
	for i in 3:
		var gy = body_bot + 1.5 + i * 1.8
		draw_line(Vector2(grip_cx - 1.2, gy), Vector2(grip_cx + 1.2, gy), silver_mid, 0.6)

	# ── Magazine (drops below receiver center) ─────────────────
	var mag_cx = recv_x - 1.0
	var mag_pts = PackedVector2Array([
		Vector2(mag_cx - 2.5, body_bot),
		Vector2(mag_cx + 2.5, body_bot),
		Vector2(mag_cx + 2.0, body_bot + 8.0),
		Vector2(mag_cx - 2.0, body_bot + 8.0),
	])
	draw_colored_polygon(mag_pts, silver_dark)
	# Mag baseplate
	draw_line(Vector2(mag_cx - 2.0, body_bot + 8.0), Vector2(mag_cx + 2.0, body_bot + 8.0), silver_mid, 1.5)
	# Mag highlight edge
	draw_line(Vector2(mag_cx - 2.5, body_bot), Vector2(mag_cx - 2.0, body_bot + 8.0), silver_mid, 0.8)

	# ── Barrel ────────────────────────────────────────────────
	# Lower barrel tube
	draw_line(Vector2(brl_start, body_mid + 1.5), Vector2(brl_end, body_mid + 1.5), silver_dark, 2.5)
	# Upper barrel (slightly thinner, brighter)
	draw_line(Vector2(brl_start, body_mid - 0.5), Vector2(brl_end - 2.0, body_mid - 0.5), silver_mid, 1.5)
	# Barrel shine highlight along top
	draw_line(Vector2(brl_start, body_mid - 1.5), Vector2(brl_end - 2.0, body_mid - 1.5), silver_shine, 0.8)
	# Muzzle block
	draw_rect(Rect2(brl_end - 2.5, body_mid - 2.5, 2.5, 5.0), silver_dark)
	draw_rect(Rect2(brl_end - 2.5, body_mid - 2.5, 2.5, 1.0), silver_shine)
	# Muzzle brake slots (two vents)
	draw_line(Vector2(brl_end - 1.8, body_mid - 2.5), Vector2(brl_end - 1.8, body_mid + 2.5), scope_dark, 0.7)

	# ── Under-barrel rail / foregrip nub ──────────────────────
	draw_rect(Rect2(brl_start + 1.0, body_mid + 2.5, 7.0, 1.5), silver_dark)

	# ── Scope ─────────────────────────────────────────────────
	var scope_x1 = grip_x + 2.0
	var scope_x2 = brl_start + 1.0
	var scope_y  = body_top - 5.5
	var scope_h  = 4.0
	# Scope body
	draw_rect(Rect2(scope_x1, scope_y, scope_x2 - scope_x1, scope_h), scope_dark)
	# Scope top shine
	draw_line(Vector2(scope_x1, scope_y), Vector2(scope_x2, scope_y), silver_mid, 0.8)
	# Scope mount legs (two small pillars connecting to rail)
	draw_line(Vector2(scope_x1 + 2.0, scope_y + scope_h), Vector2(scope_x1 + 2.0, body_top), silver_dark, 1.2)
	draw_line(Vector2(scope_x2 - 2.0, scope_y + scope_h), Vector2(scope_x2 - 2.0, body_top), silver_dark, 1.2)
	# Scope lenses (left and right ends)
	draw_circle(Vector2(scope_x1, scope_y + scope_h * 0.5), 2.2, scope_dark)
	draw_circle(Vector2(scope_x1, scope_y + scope_h * 0.5), 1.4, scope_lens)
	draw_circle(Vector2(scope_x2, scope_y + scope_h * 0.5), 2.2, scope_dark)
	draw_circle(Vector2(scope_x2, scope_y + scope_h * 0.5), 1.4, scope_lens)
	# Scope center crosshair dot (tiny accent)
	var scope_mid_x = (scope_x1 + scope_x2) * 0.5
	draw_circle(Vector2(scope_mid_x, scope_y + scope_h * 0.5), 0.8, accent)

	# ── Trigger guard ──────────────────────────────────────────
	# Small arc below grip: just two lines forming a partial loop
	var tg_x = grip_cx + 1.0
	draw_line(Vector2(tg_x - 2.5, body_bot), Vector2(tg_x - 3.0, body_bot + 4.5), silver_mid, 0.8)
	draw_line(Vector2(tg_x + 2.5, body_bot), Vector2(tg_x + 3.0, body_bot + 4.5), silver_mid, 0.8)
	draw_line(Vector2(tg_x - 3.0, body_bot + 4.5), Vector2(tg_x + 3.0, body_bot + 4.5), silver_mid, 0.8)

func _draw_knife() -> void:
	var cx     = size.x * 0.5
	var cy     = size.y * 0.5
	var center = Vector2(cx, cy)
	var dir    = Vector2(1.0, -1.0).normalized()   # blade points upper-right
	var perp   = Vector2(1.0,  1.0).normalized()   # perpendicular (lower-right)
	var rarity = item_data.get("rarity", "grey")

	# ── Colors ────────────────────────────────────────────────
	var blade_c  : Color
	var edge_c   : Color
	var guard_c  : Color
	var handle_c : Color

	match rarity:
		"grey":
			blade_c  = Color(0.52, 0.54, 0.58)
			edge_c   = Color(0.78, 0.80, 0.84)
			guard_c  = Color(0.38, 0.40, 0.44)
			handle_c = Color(0.32, 0.22, 0.12)
		"white":
			blade_c  = Color(0.86, 0.89, 0.96)
			edge_c   = Color(1.00, 1.00, 1.00)
			guard_c  = Color(0.58, 0.60, 0.68)
			handle_c = Color(0.42, 0.38, 0.50)
		"gold":
			blade_c  = Color(0.90, 0.70, 0.10)
			edge_c   = Color(1.00, 0.95, 0.40)
			guard_c  = Color(0.68, 0.52, 0.18)
			handle_c = Color(0.52, 0.28, 0.08)
		_:
			blade_c  = Color(0.5, 0.5, 0.5)
			edge_c   = Color(0.8, 0.8, 0.8)
			guard_c  = Color(0.4, 0.4, 0.4)
			handle_c = Color(0.3, 0.2, 0.1)

	var tip        = center + dir  * 15.0
	var guard_ctr  = center - dir  *  1.0
	var handle_end = center - dir  * 12.0

	# ── Equipped glow ─────────────────────────────────────────
	if item_data.get("equipped", false):
		var eq_a = 0.35 + sin(_t * 4.0) * 0.18
		var gc : Color
		match rarity:
			"grey":  gc = Color(0.70, 0.85, 1.00)
			"white": gc = Color(1.00, 1.00, 1.00)
			"gold":  gc = Color(1.00, 0.90, 0.20)
			_:       gc = Color(0.70, 0.85, 1.00)
		draw_circle(center, 22.0, Color(gc.r, gc.g, gc.b, eq_a * 0.18))
		draw_circle(center, 16.0, Color(gc.r, gc.g, gc.b, eq_a * 0.30))
		draw_circle(center, 10.0, Color(gc.r, gc.g, gc.b, eq_a * 0.20))

	# ── Gold inherent aura ─────────────────────────────────────
	if rarity == "gold" and not item_data.get("equipped", false):
		var ga = 0.28 + sin(_t * 3.0) * 0.10
		draw_circle(center, 19.0, Color(1.0, 0.80, 0.05, ga * 0.22))
		draw_circle(center, 13.0, Color(1.0, 0.88, 0.15, ga * 0.32))
		draw_circle(center,  8.0, Color(1.0, 0.95, 0.30, ga * 0.18))

	# ── Blade (filled triangle) ────────────────────────────────
	var blade_pts = PackedVector2Array([
		tip,
		guard_ctr + perp * 2.8,
		guard_ctr - perp * 2.8,
	])
	draw_colored_polygon(blade_pts, blade_c)
	# Edge shine along top of blade
	draw_line(tip, guard_ctr + perp * 2.5, edge_c, 1.0)

	# ── Guard ─────────────────────────────────────────────────
	draw_line(guard_ctr + perp * 6.0, guard_ctr - perp * 6.0, guard_c, 2.8)
	draw_circle(guard_ctr + perp * 6.0, 1.5, guard_c.lightened(0.2))
	draw_circle(guard_ctr - perp * 6.0, 1.5, guard_c.lightened(0.2))

	# ── Handle ────────────────────────────────────────────────
	draw_line(guard_ctr, handle_end, handle_c, 3.8)
	# Wrap bands
	for i in 3:
		var frac = 0.15 + i * 0.25
		var hp   = guard_ctr.lerp(handle_end, frac)
		draw_line(hp + perp * 2.2, hp - perp * 2.2, handle_c.lightened(0.28), 1.2)
	# Pommel
	draw_circle(handle_end, 3.0, guard_c)
	draw_circle(handle_end, 1.8, guard_c.lightened(0.3))
