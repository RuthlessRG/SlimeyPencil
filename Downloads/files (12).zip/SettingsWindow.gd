extends CanvasLayer

# ============================================================
#  SettingsWindow.gd
#  Cogwheel button top-right.  Volume sliders (music + SFX),
#  Quit, and Back to Character Select.
# ============================================================

signal request_character_select   # emit to scene to return to char select

var _open      : bool  = false
var _panel     : Panel = null
var _btn       : Button = null
var _scene_ref : Node  = null   # the SpaceportScene (or whichever scene owns us)

# Volume state (0.0 – 1.0)
var music_vol : float = 0.80
var sfx_vol   : float = 0.90

func init(scene: Node) -> void:
	layer      = 20
	_scene_ref = scene
	_build_button()

func _build_button() -> void:
	var vp = get_viewport().get_visible_rect().size

	_btn               = Button.new()
	_btn.text          = "⚙"
	_btn.size          = Vector2(32, 32)
	_btn.position      = Vector2(vp.x - 44, 12)   # far-right
	_btn.add_theme_font_size_override("font_size", 18)
	_btn.add_theme_color_override("font_color", Color(0.80, 0.88, 1.00))

	var sty = StyleBoxFlat.new()
	sty.bg_color     = Color(0.06, 0.08, 0.18, 0.92)
	sty.border_color = Color(0.35, 0.65, 1.00, 0.80)
	sty.set_border_width_all(2); sty.set_corner_radius_all(6)
	var sty_hov = sty.duplicate() as StyleBoxFlat
	sty_hov.bg_color = Color(0.12, 0.20, 0.40, 0.95)
	_btn.add_theme_stylebox_override("normal",  sty)
	_btn.add_theme_stylebox_override("hover",   sty_hov)
	_btn.add_theme_stylebox_override("pressed", sty_hov)
	_btn.pressed.connect(_toggle)
	add_child(_btn)

func _toggle() -> void:
	if _open: _close()
	else:     _open_window()

func _open_window() -> void:
	_open = true
	var vp  = get_viewport().get_visible_rect().size
	var W   = 340.0
	var H   = 320.0
	var px  = vp.x * 0.5 - W * 0.5
	var py  = vp.y * 0.5 - H * 0.5

	_panel          = Panel.new()
	_panel.size     = Vector2(W, H)
	_panel.position = Vector2(px, py)
	var sty         = StyleBoxFlat.new()
	sty.bg_color    = Color(0.04, 0.05, 0.12, 0.97)
	sty.border_color = Color(0.35, 0.65, 1.00, 0.85)
	sty.set_border_width_all(2); sty.set_corner_radius_all(6)
	_panel.add_theme_stylebox_override("panel", sty)
	add_child(_panel)

	# Title
	var title = Label.new()
	title.text = "⚙  SETTINGS"
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", Color(0.55, 0.88, 1.00))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.size = Vector2(W, 30); title.position = Vector2(0, 14)
	_panel.add_child(title)

	var div = ColorRect.new()
	div.size = Vector2(W - 30, 1); div.position = Vector2(15, 48)
	div.color = Color(0.35, 0.65, 1.00, 0.35)
	_panel.add_child(div)

	# ── Music volume ──────────────────────────────────────────
	_add_section_label("AUDIO", 58)
	_add_slider_row("Music Volume", music_vol, 80, func(v: float):
		music_vol = v
		_apply_audio()
	)
	_add_slider_row("SFX Volume",   sfx_vol,  122, func(v: float):
		sfx_vol = v
		_apply_audio()
	)

	var div2 = ColorRect.new()
	div2.size = Vector2(W - 30, 1); div2.position = Vector2(15, 172)
	div2.color = Color(0.35, 0.65, 1.00, 0.25)
	_panel.add_child(div2)

	# ── Navigation buttons ────────────────────────────────────
	_add_section_label("NAVIGATION", 180)

	var char_btn = _make_action_btn("⬅  Back to Character Select",
		Color(0.30, 0.60, 1.00, 0.90), 200)
	char_btn.pressed.connect(_on_char_select)
	_panel.add_child(char_btn)

	var quit_btn = _make_action_btn("✕  Quit Game",
		Color(0.85, 0.25, 0.25, 0.90), 246)
	quit_btn.pressed.connect(_on_quit)
	_panel.add_child(quit_btn)

	# Close
	var close_btn = _make_action_btn("Close", Color(0.20, 0.25, 0.40, 0.90), H - 46)
	close_btn.pressed.connect(_close)
	_panel.add_child(close_btn)

# ── UI helpers ────────────────────────────────────────────────
func _add_section_label(text: String, y: float) -> void:
	var lbl = Label.new()
	lbl.text = text
	lbl.add_theme_font_size_override("font_size", 11)
	lbl.add_theme_color_override("font_color", Color(0.45, 0.78, 1.00))
	lbl.position = Vector2(16, y); lbl.size = Vector2(300, 18)
	_panel.add_child(lbl)

func _add_slider_row(label: String, init_val: float, y: float, cb: Callable) -> void:
	var W = _panel.size.x
	var lbl = Label.new()
	lbl.text = label
	lbl.add_theme_font_size_override("font_size", 13)
	lbl.add_theme_color_override("font_color", Color(0.82, 0.88, 0.96))
	lbl.position = Vector2(16, y); lbl.size = Vector2(140, 20)
	_panel.add_child(lbl)

	var pct_lbl = Label.new()
	pct_lbl.text = "%d%%" % int(init_val * 100)
	pct_lbl.add_theme_font_size_override("font_size", 13)
	pct_lbl.add_theme_color_override("font_color", Color(1.00, 0.90, 0.50))
	pct_lbl.position = Vector2(W - 50, y); pct_lbl.size = Vector2(40, 20)
	pct_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_panel.add_child(pct_lbl)

	var slider = HSlider.new()
	slider.min_value = 0.0; slider.max_value = 1.0
	slider.step      = 0.01; slider.value    = init_val
	slider.size = Vector2(W - 32, 20)
	slider.position  = Vector2(16, y + 20)
	slider.value_changed.connect(func(v: float):
		pct_lbl.text = "%d%%" % int(v * 100)
		cb.call(v)
	)
	_panel.add_child(slider)

func _make_action_btn(text: String, border_col: Color, y: float) -> Button:
	var W   = _panel.size.x
	var btn = Button.new()
	btn.text = text
	btn.size = Vector2(W - 30, 36)
	btn.position = Vector2(15, y)
	btn.add_theme_font_size_override("font_size", 13)
	btn.add_theme_color_override("font_color", Color(0.88, 0.92, 1.00))
	var bs = StyleBoxFlat.new()
	bs.bg_color = Color(0.06, 0.10, 0.22, 0.92)
	bs.border_color = border_col
	bs.set_border_width_all(1); bs.set_corner_radius_all(4)
	var bsh = bs.duplicate() as StyleBoxFlat
	bsh.bg_color = Color(0.12, 0.20, 0.38, 0.98)
	btn.add_theme_stylebox_override("normal", bs)
	btn.add_theme_stylebox_override("hover",  bsh)
	return btn

func _apply_audio() -> void:
	# Apply to Godot audio buses
	var m_bus = AudioServer.get_bus_index("Music")
	var s_bus = AudioServer.get_bus_index("SFX")
	if m_bus >= 0:
		AudioServer.set_bus_volume_db(m_bus, linear_to_db(music_vol))
	if s_bus >= 0:
		AudioServer.set_bus_volume_db(s_bus, linear_to_db(sfx_vol))

func _on_char_select() -> void:
	_close()
	emit_signal("request_character_select")
	# Fall back: reload scene if signal not connected
	if _scene_ref and _scene_ref.has_method("_go_to_char_select"):
		_scene_ref.call("_go_to_char_select")
	else:
		get_tree().reload_current_scene()

func _on_quit() -> void:
	get_tree().quit()

func _close() -> void:
	_open = false
	if _panel and is_instance_valid(_panel):
		_panel.queue_free()
		_panel = null

func _input(event: InputEvent) -> void:
	if _open and event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		_close()
