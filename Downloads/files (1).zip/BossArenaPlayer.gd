extends CharacterBody2D

# ============================================================
#  BossArenaPlayer.gd — Beyond the Veil | Boss Arena
# ============================================================

const SPEED = 55.0

# ── CLASS & STATS ─────────────────────────────────────────────
var character_class : String = "melee"
var character_name  : String = "Player"
var level           : int    = 1
var hp              : float  = 200.0
var max_hp          : float  = 200.0
var mp              : float  = 100.0
var max_mp          : float  = 100.0

# Base stats before attribute bonuses
var _base_max_hp : float = 200.0
var _base_max_mp : float = 100.0

# ── ATTRIBUTES ────────────────────────────────────────────────
# STR: +25 HP, +5 melee dmg, +5% dmg reduction per point
# AGI: +5% attack speed, +2% crit chance per point
# INT: +5% spell dmg, +2% spell crit per point
# SPI: +25 MP, +5 spell dmg per point
var attr_str       : int = 0
var attr_agi       : int = 0
var attr_int       : int = 0
var attr_spi       : int = 0
var unspent_points : int = 0

# ── INVENTORY ─────────────────────────────────────────────────
# Each entry is a dict: {id, name, type, rarity, cost,
#   attr_str, attr_agi, attr_int, attr_spi, desc, equipped}
var inventory : Array = []

# Item bonus totals — recomputed in _recalc_stats from equipped items
var _item_str : int = 0
var _item_agi : int = 0
var _item_int : int = 0
var _item_spi : int = 0

# ── CREDITS & EXPERIENCE ──────────────────────────────────────
var credits       : int = 0
var _float_stack  : int = 0   # tracks stacked floating texts
var exp_points : float = 0.0
var exp_needed : float = 100.0   # scales: 100 * level

# ── FACING & ANIMATION ────────────────────────────────────────
var _facing      : String = "s"
var _is_attacking: bool   = false
var _moving      : bool   = false

# ── AUTO-ATTACK ───────────────────────────────────────────────
var _attack_timer   : float = 0.0
var _move_lock_timer: float = 0.0
var _one_shot_kill  : bool  = false

# ── DEATH ─────────────────────────────────────────────────────
const DEATH_DURATION : float = 2.0
var _dying       : bool  = false
var _death_timer : float = 0.0

# ── TARGET SYSTEM ─────────────────────────────────────────────
var _current_target    : Node  = null
var _target_candidates : Array = []
var _target_idx        : int   = -1
var _target_scan_timer : float = 0.0

const TARGET_SCAN_RATE    = 0.10
const TARGET_CONE_RANGE   = 700.0
const TARGET_CIRCLE_RANGE = 800.0
const TARGET_CONE_ANGLE   = 60.0

# ── READY ─────────────────────────────────────────────────────
func _ready() -> void:
	add_to_group("player")
	_setup_stats()
	_spawn_chat()

func _spawn_chat() -> void:
	var script = load("res://Scripts/BossChatWindow.gd")
	var chat   = CanvasLayer.new()
	chat.name  = "ChatWindow"
	chat.set_script(script)
	add_child(chat)
	chat.call("init", self)

func _setup_stats() -> void:
	match character_class:
		"melee":
			character_name = "Melee Fighter"
			_base_max_hp   = 300.0
			_base_max_mp   = 60.0
		"ranged":
			character_name = "Ranger"
			_base_max_hp   = 180.0
			_base_max_mp   = 100.0
		"mage":
			character_name = "Mage"
			_base_max_hp   = 150.0
			_base_max_mp   = 200.0
		"brawler":
			character_name = "Brawler"
			_base_max_hp   = 350.0
			_base_max_mp   = 60.0
	_recalc_stats()
	hp = max_hp
	mp = max_mp

func _recalc_stats() -> void:
	# Recompute item bonuses from currently equipped items
	_item_str = 0; _item_agi = 0; _item_int = 0; _item_spi = 0
	for item in inventory:
		if item.get("equipped", false):
			_item_str += item.get("attr_str", 0)
			_item_agi += item.get("attr_agi", 0)
			_item_int += item.get("attr_int", 0)
			_item_spi += item.get("attr_spi", 0)
	max_hp = _base_max_hp + (attr_str + _item_str) * 25.0
	max_mp = _base_max_mp + (attr_spi + _item_spi) * 25.0
	hp = minf(hp, max_hp)
	mp = minf(mp, max_mp)

# ── CREDITS & PROGRESSION ─────────────────────────────────────
func add_credits(amount: int) -> void:
	credits += amount
	_spawn_floating_text("+%d ¢" % amount, Color(1.0, 0.85, 0.20))

func add_exp(amount: float) -> void:
	exp_points += amount
	_spawn_floating_text("+%d XP" % int(amount), Color(0.75, 0.25, 1.0))
	while exp_points >= exp_needed:
		exp_points -= exp_needed
		_level_up()

func _spawn_floating_text(text: String, color: Color) -> void:
	var script = load("res://Scripts/BossFloatingText.gd")
	var node   = Node2D.new()
	node.set_script(script)
	var scene  = get_tree().current_scene
	if scene == null:
		return
	node.global_position = global_position + Vector2(randf_range(-8, 8), -40 - _float_stack * 20)
	_float_stack += 1
	scene.add_child(node)
	node.call("init", text, color)
	get_tree().create_timer(1.4).timeout.connect(func(): _float_stack = max(0, _float_stack - 1))

func _level_up() -> void:
	level         += 1
	unspent_points += 3
	exp_needed     = 100.0 * level
	_recalc_stats()
	hp = max_hp   # full heal on level up
	mp = max_mp
	var arena = get_tree().get_first_node_in_group("boss_arena_scene")
	if arena and arena.has_method("trigger_level_up"):
		arena.call("trigger_level_up", level)

func spend_point(attr: String) -> void:
	if unspent_points <= 0:
		return
	match attr:
		"str": attr_str += 1
		"agi": attr_agi += 1
		"int": attr_int += 1
		"spi": attr_spi += 1
		_: return
	unspent_points -= 1
	_recalc_stats()

# ── PROCESS ───────────────────────────────────────────────────
func _process(delta: float) -> void:
	if _dying:
		_tick_death(delta)
		queue_redraw()
		return

	_target_scan_timer -= delta
	if _target_scan_timer <= 0.0:
		_target_scan_timer = TARGET_SCAN_RATE
		_refresh_target_candidates()

	if _move_lock_timer > 0.0:
		_move_lock_timer -= delta

	_tick_auto_attack(delta)
	_update_animation()
	queue_redraw()

func _tick_death(delta: float) -> void:
	_death_timer += delta
	var blink = absf(sin(_death_timer * 14.0))
	var fade  = 1.0 - clampf((_death_timer - 1.4) / 0.6, 0.0, 1.0)
	modulate.a = blink * fade
	if _death_timer >= DEATH_DURATION:
		queue_free()

func _physics_process(_delta: float) -> void:
	if _dying:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	if _move_lock_timer > 0.0:
		velocity = Vector2.ZERO
		_moving  = false
		move_and_slide()
		return

	var input = Vector2.ZERO
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		input.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		input.y += 1.0
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		input.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		input.x += 1.0

	_moving = input != Vector2.ZERO
	if _moving:
		velocity = input.normalized() * SPEED
		if input.y < 0.0:
			_facing = "n"
		elif input.y > 0.0:
			_facing = "s"
		elif input.x > 0.0:
			_facing = "e"
		else:
			_facing = "w"
	else:
		velocity = Vector2.ZERO

	move_and_slide()

func _input(event: InputEvent) -> void:
	if _dying:
		return
	# Don't fire game keys while chat input has keyboard focus
	if event is InputEventKey:
		var focused = get_viewport().gui_get_focus_owner()
		if focused is LineEdit:
			return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_TAB:
			_cycle_target()
		elif event.keycode == KEY_ESCAPE:
			# Close any open window first; if none, clear target
			var window_names = ["ShopWindow", "InventoryWindow", "AttributeWindow"]
			var closed = false
			for wname in window_names:
				var win = get_node_or_null(wname)
				if win:
					win.queue_free()
					closed = true
					break
			if not closed:
				_current_target = null
				_target_idx     = -1
				_cancel_attack()
		elif event.keycode == KEY_G:
			_one_shot_kill = true
		elif event.keycode == KEY_I:
			_toggle_inventory()
		elif event.keycode == KEY_C:
			_toggle_attributes()
		elif event.keycode == KEY_F:
			_try_open_shop()
		elif event.keycode == KEY_H:
			credits += 500   # debug: +500 credits

# ── WINDOW TOGGLES ────────────────────────────────────────────
func _toggle_inventory() -> void:
	var existing = get_node_or_null("InventoryWindow")
	if existing:
		existing.queue_free()
		return
	var script = load("res://Scripts/BossInventoryWindow.gd")
	var win    = CanvasLayer.new()
	win.name   = "InventoryWindow"
	win.set_script(script)
	add_child(win)
	win.call("init", self)

func _toggle_attributes() -> void:
	var existing = get_node_or_null("AttributeWindow")
	if existing:
		existing.queue_free()
		return
	var script = load("res://Scripts/BossAttributeWindow.gd")
	var win    = CanvasLayer.new()
	win.name   = "AttributeWindow"
	win.set_script(script)
	add_child(win)
	win.call("init", self)

func _try_open_shop() -> void:
	var terminals = get_tree().get_nodes_in_group("shop_terminal")
	for t in terminals:
		if is_instance_valid(t) and global_position.distance_to(t.global_position) <= 58.0:
			_toggle_shop()
			return

func _toggle_shop() -> void:
	var existing = get_node_or_null("ShopWindow")
	if existing:
		existing.queue_free()
		return
	var script = load("res://Scripts/BossShopWindow.gd")
	var win    = CanvasLayer.new()
	win.name   = "ShopWindow"
	win.set_script(script)
	add_child(win)
	win.call("init", self)

# ── INVENTORY / ITEM SYSTEM ───────────────────────────────────
func add_item_to_inventory(item: Dictionary) -> void:
	var copy          = item.duplicate()
	copy["equipped"]  = false
	inventory.append(copy)

func toggle_equip(inv_index: int) -> void:
	if inv_index < 0 or inv_index >= inventory.size():
		return
	inventory[inv_index]["equipped"] = not inventory[inv_index]["equipped"]
	_recalc_stats()

# ── ANIMATION ─────────────────────────────────────────────────
func _update_animation() -> void:
	var sprite = get_node_or_null("Sprite") as AnimatedSprite2D
	if sprite == null or sprite.sprite_frames == null:
		return

	# Kiting: moving after firing cancels attack animation for projectile classes
	if _is_attacking and _moving and (character_class == "ranged" or character_class == "mage"):
		_cancel_attack()

	var anim : String
	if _is_attacking:
		anim = "attack_" + _facing
	elif _moving:
		anim = "run_" + _facing
	else:
		anim = "idle_" + _facing

	if sprite.sprite_frames.has_animation(anim):
		if sprite.animation != anim:
			sprite.play(anim)
	else:
		if sprite.sprite_frames.has_animation("idle_s") and sprite.animation != "idle_s":
			sprite.play("idle_s")

# ── PLACEHOLDER DRAW ──────────────────────────────────────────
func _draw() -> void:
	# Nameplate — always visible above head (ready for multiplayer targeting later)
	if character_name.length() > 0:
		var font    = ThemeDB.fallback_font
		var font_sz = 9
		var name_y  = -50.0 if character_class == "brawler" else -30.0
		var text_w  = font.get_string_size(character_name, HORIZONTAL_ALIGNMENT_LEFT, -1, font_sz).x
		var text_pos = Vector2(-text_w * 0.5, name_y)
		# Black outline — draw at 1px offsets in 4 directions
		for ox in [-1, 1]:
			for oy in [-1, 1]:
				draw_string(font, text_pos + Vector2(ox, oy), character_name,
					HORIZONTAL_ALIGNMENT_LEFT, -1, font_sz, Color(0.0, 0.0, 0.0, 0.90))
		draw_string(font, text_pos, character_name,
			HORIZONTAL_ALIGNMENT_LEFT, -1, font_sz, Color(0.90, 0.95, 1.0, 0.95))

	var sprite = get_node_or_null("Sprite") as AnimatedSprite2D
	if sprite and sprite.sprite_frames and sprite.sprite_frames.get_animation_names().size() > 0:
		return

	var col = _get_class_color()
	draw_circle(Vector2.ZERO, 14.0, col)
	draw_circle(Vector2.ZERO, 11.0, col.lightened(0.25))
	var fwd = _facing_to_vec() * 10.0
	draw_circle(fwd, 4.0, Color.WHITE)
	var shadow_pts := PackedVector2Array()
	for i in 12:
		var a = float(i) / 12.0 * TAU
		shadow_pts.append(Vector2(cos(a) * 14.0, sin(a) * 5.0) + Vector2(0, 16))
	draw_colored_polygon(shadow_pts, Color(0, 0, 0, 0.22))

func _get_class_color() -> Color:
	match character_class:
		"melee":   return Color(0.9,  0.35, 0.20)
		"ranged":  return Color(0.35, 0.75, 0.90)
		"mage":    return Color(0.70, 0.40, 1.00)
		"brawler": return Color(0.40, 0.85, 0.30)
	return Color.WHITE

func _facing_to_vec() -> Vector2:
	match _facing:
		"n": return Vector2(0, -1)
		"s": return Vector2(0,  1)
		"e": return Vector2(1,  0)
		"w": return Vector2(-1, 0)
	return Vector2(0, 1)

# ── AUTO-ATTACK ───────────────────────────────────────────────
func _tick_auto_attack(delta: float) -> void:
	if _current_target == null or not is_instance_valid(_current_target):
		return

	var attack_interval : float
	var attack_range    : float
	match character_class:
		"melee":
			attack_interval = 2.0
			attack_range    = 130.0
		"ranged":
			attack_interval = 2.5
			attack_range    = 700.0
		"mage":
			attack_interval = 4.0
			attack_range    = 700.0
		"brawler":
			attack_interval = 2.0
			attack_range    = 130.0
		_:
			attack_interval = 2.0
			attack_range    = 130.0

	# AGI (+ item AGI) gives +5% attack speed per point
	attack_interval /= (1.0 + (attr_agi + _item_agi) * 0.05)

	var dist = global_position.distance_to(_current_target.global_position)
	if dist > attack_range:
		_cancel_attack()
		return

	_attack_timer -= delta
	if _attack_timer <= 0.0:
		_attack_timer = attack_interval
		_do_attack()

func _do_attack() -> void:
	if _current_target == null or not is_instance_valid(_current_target):
		return

	match character_class:
		"melee":   _move_lock_timer = 0.0
		"ranged":  _move_lock_timer = 0.0
		"mage":    _move_lock_timer = 0.0
		"brawler": _move_lock_timer = 0.0

	var to_target = _current_target.global_position - global_position
	if absf(to_target.x) >= absf(to_target.y):
		_facing = "e" if to_target.x > 0.0 else "w"
	else:
		_facing = "s" if to_target.y > 0.0 else "n"

	var sprite = get_node_or_null("Sprite") as AnimatedSprite2D
	if sprite and sprite.sprite_frames:
		var anim_name = "attack_" + _facing
		if sprite.sprite_frames.has_animation(anim_name):
			sprite.play(anim_name)
			_is_attacking = true
			if not sprite.animation_finished.is_connected(_on_attack_anim_done):
				sprite.animation_finished.connect(_on_attack_anim_done, CONNECT_ONE_SHOT)

	var dmg : float
	if _one_shot_kill:
		var target_hp = _current_target.get("hp")
		dmg = target_hp if target_hp != null else 99999.0
		_one_shot_kill = false
	else:
		dmg = _get_attack_damage()

	var arena = get_tree().get_first_node_in_group("boss_arena_scene")

	if character_class == "mage":
		var spawn_pos = global_position + _facing_to_vec() * 18.0
		if arena and arena.has_method("spawn_fireball"):
			arena.spawn_fireball(spawn_pos, _current_target, dmg)
	elif character_class == "ranged":
		var spawn_pos = global_position + _facing_to_vec() * 18.0
		# Check for equipped rifle — passes glow flag and spawns shoot visual
		var has_rifle = false
		for item in inventory:
			if item.get("equipped", false) and item.get("type", "") == "rifle":
				has_rifle = true
				break
		if arena and arena.has_method("spawn_bullet"):
			var bullet = arena.spawn_bullet(spawn_pos, _current_target, dmg)
			if bullet != null and has_rifle:
				bullet.set("rifle_glow", true)
		_try_spawn_weapon_swing()
	else:
		if _current_target.has_method("take_damage"):
			_current_target.take_damage(dmg)
		if arena and arena.has_method("spawn_damage_number"):
			arena.spawn_damage_number(_current_target.global_position, dmg, _get_dmg_color())
		if arena and arena.has_method("spawn_melee_hit"):
			var aim = _current_target.get_target_position() if _current_target.has_method("get_target_position") else _current_target.global_position
			var hit_pos = aim + Vector2(randf_range(-12.0, 12.0), randf_range(-18.0, 18.0))
			arena.spawn_melee_hit(hit_pos, _get_dmg_color())
		# Weapon swing visual for any equipped knife
		_try_spawn_weapon_swing()

func _try_spawn_weapon_swing() -> void:
	for item in inventory:
		var t = item.get("type", "")
		if item.get("equipped", false) and (t == "knife" or t == "rifle"):
			var script = load("res://Scripts/BossWeaponSwing.gd")
			var swing  = Node2D.new()
			swing.set_script(script)
			swing.position = Vector2(0, -15)
			add_child(swing)
			swing.call("init", item, _facing)
			return   # only one swing per attack

func _get_attack_damage() -> float:
	var eff_str = attr_str + _item_str
	var eff_agi = attr_agi + _item_agi
	var eff_int = attr_int + _item_int
	var eff_spi = attr_spi + _item_spi

	var base : float
	match character_class:
		"melee":
			base = randf_range(18.0, 28.0) + eff_str * 5.0
		"ranged":
			base = randf_range(12.0, 20.0)
		"mage":
			base = randf_range(22.0, 35.0)
			base *= (1.0 + eff_int * 0.05)
			base += eff_spi * 5.0
		"brawler":
			base = randf_range(20.0, 32.0) + eff_str * 5.0
		_:
			base = 10.0

	# AGI crit: +2% crit chance per point, crits deal 1.5x
	if randf() < eff_agi * 0.02:
		base *= 1.5

	return base

func _get_dmg_color() -> Color:
	match character_class:
		"melee":   return Color(1.0, 0.55, 0.1)
		"ranged":  return Color(0.4, 0.95, 1.0)
		"mage":    return Color(0.9, 0.5,  1.0)
		"brawler": return Color(1.0, 0.55, 0.1)
	return Color.WHITE

func _on_attack_anim_done() -> void:
	_is_attacking = false

func _cancel_attack() -> void:
	_is_attacking = false
	var sprite = get_node_or_null("Sprite") as AnimatedSprite2D
	if sprite:
		if sprite.animation_finished.is_connected(_on_attack_anim_done):
			sprite.animation_finished.disconnect(_on_attack_anim_done)

# ── TARGET SYSTEM ─────────────────────────────────────────────
func _refresh_target_candidates() -> void:
	var all_targets = get_tree().get_nodes_in_group("targetable")

	var fwd = _facing_to_vec()
	var cone_hits   : Array = []
	var circle_hits : Array = []

	for node in all_targets:
		if not is_instance_valid(node):
			continue
		if node == self:
			continue
		var to_node = node.global_position - global_position
		var dist    = to_node.length()

		if dist < TARGET_CONE_RANGE:
			var angle_diff = fwd.angle_to(to_node.normalized())
			if absf(angle_diff) < deg_to_rad(TARGET_CONE_ANGLE):
				cone_hits.append({"node": node, "dist": dist})

		if dist < TARGET_CIRCLE_RANGE:
			circle_hits.append({"node": node, "dist": dist})

	cone_hits.sort_custom(func(a, b): return a.dist < b.dist)
	circle_hits.sort_custom(func(a, b): return a.dist < b.dist)

	var new_candidates : Array = []
	for h in cone_hits:
		new_candidates.append(h.node)
	for h in circle_hits:
		if not new_candidates.has(h.node):
			new_candidates.append(h.node)

	_target_candidates = new_candidates

	if _current_target != null:
		if not is_instance_valid(_current_target) or not _target_candidates.has(_current_target):
			_current_target = null
			_target_idx = -1
		else:
			_target_idx = _target_candidates.find(_current_target)

func _cycle_target() -> void:
	if _target_candidates.is_empty():
		_current_target = null
		return
	_target_idx = (_target_idx + 1) % _target_candidates.size()
	_current_target = _target_candidates[_target_idx]
	_attack_timer = 0.5

# ── PUBLIC INTERFACE ──────────────────────────────────────────
func get_current_target() -> Node:
	return _current_target

func is_targeted(node: Node) -> bool:
	return node == _current_target

# ── DAMAGE / DEATH ────────────────────────────────────────────
func take_damage(amount: float) -> void:
	if _dying:
		return
	# STR (+ item STR): +5% damage reduction per point
	var reduction = (attr_str + _item_str) * 0.05
	amount *= maxf(0.0, 1.0 - reduction)
	hp = maxf(0.0, hp - amount)
	if hp <= 0.0:
		_die()

func _die() -> void:
	_dying = true
	_current_target = null
	var arena = get_tree().get_first_node_in_group("boss_arena_scene")
	if arena and arena.has_method("on_player_died"):
		arena.call("on_player_died")
