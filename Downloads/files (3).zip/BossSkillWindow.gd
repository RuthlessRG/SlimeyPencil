extends CanvasLayer

# ============================================================
#  BossSkillWindow.gd — skill browser, opened with P
#  Lists all skills. Player drags icons onto the action bar.
#  Matches the dark terminal glass aesthetic of the shop.
# ============================================================

const SKILLS : Array = [
	{
		"id":          "sprint",
		"name":        "Sprint",
		"icon":        "sprint",
		"req_level":   1,
		"cooldown":    60.0,
		"desc":        "+30% move speed for 15s",
		"detail":      "60s cooldown",
	},
	{
		"id":          "sensu_bean",
		"name":        "Sensu Bean",
		"icon":        "sensu",
		"req_level":   3,
		"cooldown":    60.0,
		"desc":        "Restore full HP & MP over 10s",
		"detail":      "60s cooldown",
	},
	{
		"id":          "triple_strike",
		"name":        "Triple Strike",
		"icon":        "triple",
		"req_level":   5,
		"cooldown":    0.0,
		"desc":        "Attack 3 times instantly",
		"detail":      "No cooldown",
	},
]

const RARITY_COLOR : Dictionary = {
	"grey":  Color(0.75, 0.76, 0.80),
	"white": Color(0.95, 0.96, 1.00),
	"gold":  Color(1.00, 0.85, 0.20),
	"blue":  Color(0.35, 0.72, 1.00),
}

var _player       : Node  = null
var _panel        : Panel = null
var _drag_active  : bool  = false
var _drag_offset  : Vector2 = Vector2.ZERO

func init(player: Node) -> void:
	layer   = 15
	_player = player
	_build_ui()

func _build_ui() -> void:
	var vp      = get_viewport().get_visible_rect().size
	const WIN_W : float = 500.0
	const ICON  : float = 52.0
	const ROW_H : float = 72.0
	const HDR_H : float = 54.0
	const FTR_H : float = 44.0
	var win_h   = HDR_H + SKILLS.size() * ROW_H + FTR_H
	var win_x   = vp.x * 0.5 - WIN_W * 0.5
	var win_y   = vp.y * 0.5 - win_h * 0.5 - 40.0

	_panel          = Panel.new()
	_panel.position = Vector2(win_x, win_y)
	_panel.size     = Vector2(WIN_W, win_h)
	var sty         = StyleBoxFlat.new()
	sty.bg_color    = Color(0.03, 0.04, 0.10, 0.94)
	sty.set_border_width_all(0)
	_panel.add_theme_stylebox_override("panel", sty)
	add_child(_panel)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.gui_input.connect(_on_panel_gui_input)

	# Scanlines
	var scan = Control.new()
	scan.size         = Vector2(WIN_W, win_h)
	scan.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scan.set_script(_scanline_script(WIN_W, win_h))
	_panel.add_child(scan)

	# Top/bot accent bars
	var top_bar      = ColorRect.new()
	top_bar.size     = Vector2(WIN_W, 5)
	top_bar.color    = Color(0.55, 0.30, 1.00, 0.92)
	top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(top_bar)
	var bot_bar      = ColorRect.new()
	bot_bar.size     = Vector2(WIN_W, 4)
	bot_bar.position = Vector2(0, win_h - 4)
	bot_bar.color    = Color(0.55, 0.30, 1.00, 0.45)
	bot_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(bot_bar)

	# Title
	var title = Label.new()
	title.text = "S K I L L S"
	title.add_theme_font_size_override("font_size", 15)
	title.add_theme_color_override("font_color", Color(0.75, 0.55, 1.0))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.size     = Vector2(WIN_W, 22)
	title.position = Vector2(0, 10)
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(title)

	var sub = Label.new()
	sub.text = "DRAG SKILLS TO ACTION BAR  ·  PRESS 1–5 TO USE"
	sub.add_theme_font_size_override("font_size", 9)
	sub.add_theme_color_override("font_color", Color(0.50, 0.38, 0.75, 0.80))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.size     = Vector2(WIN_W, 14)
	sub.position = Vector2(0, 32)
	sub.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(sub)

	var hsep       = ColorRect.new()
	hsep.size      = Vector2(WIN_W - 20, 1)
	hsep.position  = Vector2(10, HDR_H - 1)
	hsep.color     = Color(0.45, 0.25, 0.90, 0.35)
	hsep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(hsep)

	# Skill rows
	for idx in SKILLS.size():
		_build_skill_row(idx, HDR_H + idx * ROW_H, WIN_W, ICON, ROW_H)
		if idx < SKILLS.size() - 1:
			var div       = ColorRect.new()
			div.size      = Vector2(WIN_W - 20, 1)
			div.position  = Vector2(10, HDR_H + (idx + 1) * ROW_H - 1)
			div.color     = Color(0.45, 0.25, 0.90, 0.18)
			div.mouse_filter = Control.MOUSE_FILTER_IGNORE
			_panel.add_child(div)

	var fsep       = ColorRect.new()
	fsep.size      = Vector2(WIN_W - 20, 1)
	fsep.position  = Vector2(10, HDR_H + SKILLS.size() * ROW_H)
	fsep.color     = Color(0.45, 0.25, 0.90, 0.35)
	fsep.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(fsep)

	# Close button
	var btn_close      = Button.new()
	btn_close.text     = "CLOSE  [P]"
	btn_close.size     = Vector2(110, 26)
	btn_close.position = Vector2(WIN_W - 124, HDR_H + SKILLS.size() * ROW_H + 8)
	btn_close.add_theme_font_size_override("font_size", 11)
	btn_close.add_theme_color_override("font_color", Color(0.75, 0.55, 1.0))
	var btn_sty          = StyleBoxFlat.new()
	btn_sty.bg_color     = Color(0.06, 0.04, 0.14, 0.90)
	btn_sty.border_color = Color(0.55, 0.30, 1.00, 0.80)
	btn_sty.set_border_width_all(1)
	btn_sty.set_corner_radius_all(4)
	btn_close.add_theme_stylebox_override("normal", btn_sty)
	btn_close.pressed.connect(queue_free)
	_panel.add_child(btn_close)

func _build_skill_row(idx: int, row_y: float, win_w: float, icon_sz: float, row_h: float) -> void:
	var skill   = SKILLS[idx]
	var pad     = 10.0
	var plevel  = _player.get("level") as int if _player else 1
	var locked  = plevel < skill.get("req_level", 1)

	# Icon bg
	var icon_bg       = Panel.new()
	icon_bg.position  = Vector2(pad, row_y + (row_h - icon_sz) * 0.5)
	icon_bg.size      = Vector2(icon_sz, icon_sz)
	icon_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ibs           = StyleBoxFlat.new()
	ibs.bg_color      = Color(0.08, 0.06, 0.18, 0.92)
	ibs.border_color  = Color(0.45, 0.25, 0.90, 0.60) if not locked else Color(0.3, 0.3, 0.3, 0.40)
	ibs.set_border_width_all(1)
	ibs.set_corner_radius_all(3)
	icon_bg.add_theme_stylebox_override("panel", ibs)
	_panel.add_child(icon_bg)

	# Skill icon drawn inline
	var icon_draw = Control.new()
	icon_draw.size         = Vector2(icon_sz, icon_sz)
	icon_draw.mouse_filter = Control.MOUSE_FILTER_IGNORE
	icon_draw.set_script(_skill_icon_script(skill.get("icon", ""), locked))
	icon_bg.add_child(icon_draw)

	# Name
	var name_lbl = Label.new()
	name_lbl.text = skill.get("name", "")
	name_lbl.add_theme_font_size_override("font_size", 14)
	var ncol = Color(0.70, 0.50, 1.00) if not locked else Color(0.40, 0.40, 0.45)
	name_lbl.add_theme_color_override("font_color", ncol)
	name_lbl.position    = Vector2(pad + icon_sz + 10, row_y + 8)
	name_lbl.size        = Vector2(200, 20)
	name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(name_lbl)

	# Req level badge
	var req_lbl = Label.new()
	req_lbl.text = "Req. Level %d" % skill.get("req_level", 1)
	req_lbl.add_theme_font_size_override("font_size", 9)
	var rlcol = Color(1.0, 0.35, 0.35) if locked else Color(0.40, 0.75, 0.40)
	req_lbl.add_theme_color_override("font_color", rlcol)
	req_lbl.position    = Vector2(pad + icon_sz + 12, row_y + 26)
	req_lbl.size        = Vector2(140, 14)
	req_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(req_lbl)

	# Description
	var desc_lbl = Label.new()
	desc_lbl.text = skill.get("desc", "") + "  ·  " + skill.get("detail", "")
	desc_lbl.add_theme_font_size_override("font_size", 11)
	desc_lbl.add_theme_color_override("font_color", Color(0.60, 0.75, 0.60) if not locked else Color(0.35, 0.35, 0.38))
	desc_lbl.position    = Vector2(pad + icon_sz + 10, row_y + 42)
	desc_lbl.size        = Vector2(280, 18)
	desc_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(desc_lbl)

	# DRAG button
	var btn        = Button.new()
	btn.text       = "DRAG" if not locked else "LOCKED"
	btn.size       = Vector2(66, 28)
	btn.position   = Vector2(win_w - 80, row_y + (row_h - 28) * 0.5)
	btn.add_theme_font_size_override("font_size", 11)
	var btn_col = Color(0.65, 0.45, 1.0) if not locked else Color(0.40, 0.40, 0.45)
	btn.add_theme_color_override("font_color", btn_col)
	var bsty          = StyleBoxFlat.new()
	bsty.bg_color     = Color(0.06, 0.04, 0.14, 0.90)
	bsty.border_color = Color(0.50, 0.28, 0.95, 0.80) if not locked else Color(0.3, 0.3, 0.3, 0.5)
	bsty.set_border_width_all(1)
	bsty.set_corner_radius_all(4)
	btn.add_theme_stylebox_override("normal", bsty)
	if not locked:
		btn.pressed.connect(_on_drag_skill.bind(idx))
	_panel.add_child(btn)

func _on_drag_skill(idx: int) -> void:
	# Tell the action bar to start a drag from the skill window
	var skill = SKILLS[idx]
	var bar = _player.get_node_or_null("ActionBar")
	if bar and bar.has_method("begin_drag_from_window"):
		bar.call("begin_drag_from_window", skill)

func _on_panel_gui_input(event: InputEvent) -> void:
	const HDR_DRAG : float = 54.0
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed and event.position.y <= HDR_DRAG:
			_drag_active = true
			_drag_offset = event.position
		else:
			_drag_active = false
	elif event is InputEventMouseMotion and _drag_active:
		var new_pos = _panel.position + event.relative
		var vp      = get_viewport().get_visible_rect().size
		new_pos.x   = clampf(new_pos.x, 0.0, vp.x - _panel.size.x)
		new_pos.y   = clampf(new_pos.y, 0.0, vp.y - _panel.size.y)
		_panel.position = new_pos

# ── Inline skill icon script ───────────────────────────────────
func _skill_icon_script(icon_id: String, locked: bool) -> GDScript:
	var lock_str = "true" if locked else "false"
	var src = """
extends Control
var _t : float = 0.0
var _locked : bool = %s
func _process(d):
\t_t += d
\tqueue_redraw()
func _draw():
\tvar cx = size.x * 0.5
\tvar cy = size.y * 0.5
\tvar c  = Vector2(cx, cy)
\tif _locked:
\t\tdraw_circle(c, 18.0, Color(0.15, 0.15, 0.20))
\t\tdraw_line(c + Vector2(-8,-8), c + Vector2(8,8), Color(0.4,0.4,0.4,0.8), 2.0)
\t\tdraw_line(c + Vector2(8,-8), c + Vector2(-8,8), Color(0.4,0.4,0.4,0.8), 2.0)
\t\treturn
\t_draw_%s(cx, cy)
func _draw_sprint(cx, cy):
\tvar c = Vector2(cx, cy)
\tvar pulse = 0.6 + sin(_t * 4.0) * 0.2
\tdraw_circle(c, 18.0, Color(0.10, 0.40, 0.90, 0.25))
\tfor i in 5:
\t\tvar frac = float(i) / 5.0
\t\tvar x = cx - 12.0 + frac * 24.0
\t\tvar spd = 1.0 - frac * 0.35
\t\tvar yoff = sin(_t * 6.0 * spd + frac * 2.1) * 4.0
\t\tdraw_line(Vector2(x, cy + yoff - 7), Vector2(x + 6.0 * spd, cy + yoff + 7), Color(0.35, 0.80, 1.00, pulse), 2.0)
\tvar arrow = PackedVector2Array([c + Vector2(6,-5), c + Vector2(14,0), c + Vector2(6,5)])
\tdraw_colored_polygon(arrow, Color(1.0, 1.0, 1.0, pulse))
func _draw_sensu(cx, cy):
\tvar c = Vector2(cx, cy)
\tvar pulse = 0.7 + sin(_t * 2.5) * 0.18
\tdraw_circle(c, 18.0, Color(0.05, 0.30, 0.10, 0.30))
\tvar pts = PackedVector2Array()
\tfor i in 12:
\t\tvar a = float(i) / 12.0 * 6.2832
\t\tvar r = 10.0 + sin(a * 2.0 + _t * 1.8) * 3.0
\t\tpts.append(c + Vector2(cos(a)*r, sin(a)*r))
\tdraw_colored_polygon(pts, Color(0.15, 0.75, 0.25, pulse * 0.55))
\tdraw_circle(c, 5.5, Color(0.55, 1.0, 0.55, pulse))
\tdraw_circle(c, 3.0, Color(1.0, 1.0, 1.0, pulse * 0.70))
func _draw_triple(cx, cy):
\tvar c = Vector2(cx, cy)
\tvar pulse = 0.65 + sin(_t * 5.0) * 0.20
\tdraw_circle(c, 18.0, Color(0.50, 0.10, 0.10, 0.25))
\tvar offsets = [Vector2(-10,0), Vector2(0,0), Vector2(10,0)]
\tfor i in 3:
\t\tvar oc = c + offsets[i]
\t\tvar tip = oc + Vector2(0, -12)
\t\tvar bl  = oc + Vector2(-4, 4)
\t\tvar br  = oc + Vector2(4, 4)
\t\tdraw_colored_polygon(PackedVector2Array([tip, bl, br]), Color(1.0, 0.35, 0.35, pulse))
\t\tdraw_circle(oc + Vector2(0, 5), 2.5, Color(1.0, 0.60, 0.20, pulse))
""" % [lock_str, icon_id]
	var scr = GDScript.new()
	scr.source_code = src
	scr.reload()
	return scr

func _scanline_script(w: float, h: float) -> GDScript:
	var src = """
extends Control
var _w : float = %f
var _h : float = %f
func _draw() -> void:
\tvar steps = int(_h / 6.0)
\tfor i in steps:
\t\tdraw_rect(Rect2(0, i * 6, _w, 1.5), Color(1, 1, 1, 0.016))
""" % [w, h]
	var scr = GDScript.new()
	scr.source_code = src
	scr.reload()
	return scr
