extends Node2D

# ============================================================
#  SpaceportScene.gd — miniSWG | Level 1: Coronet Spaceport
#
#  World layout (8192 x 8192):
#   TOP-LEFT quadrant  — Coronet Spaceport complex
#   Rest of world      — Open grasslands, rivers, road network
#
#  Attach to a bare Node2D scene: spaceport.tscn
#  Add this to group "boss_arena_scene" for player compat.
# ============================================================

# ── WORLD ─────────────────────────────────────────────────────
const WORLD_W : float = 16384.0
const WORLD_H : float = 16384.0

# Spaceport complex sits in the top-left quadrant
const PORT_X  : float = 80.0
const PORT_Y  : float = 80.0
const PORT_W  : float = 2600.0
const PORT_H  : float = 2400.0

# ── PALETTE ───────────────────────────────────────────────────
# Sky-blue tarmac, warm tan earth, vivid greens
const C_TARMAC        = Color(0.62, 0.66, 0.72)    # blue-grey landing pad concrete
const C_TARMAC_DARK   = Color(0.50, 0.54, 0.60)
const C_TARMAC_LINE   = Color(0.95, 0.85, 0.20)    # yellow runway markings
const C_EARTH         = Color(0.68, 0.52, 0.28)    # tan dirt roads / paths
const C_GRASS_BASE    = Color(0.36, 0.62, 0.22)    # vibrant open grassland
const C_GRASS_DARK    = Color(0.28, 0.50, 0.16)
const C_GRASS_LIGHT   = Color(0.50, 0.76, 0.30)
const C_RIVER         = Color(0.22, 0.52, 0.82)
const C_RIVER_FOAM    = Color(0.60, 0.80, 1.00, 0.55)
const C_BUILDING_WALL = Color(0.88, 0.88, 0.90)    # white-ish durasteel
const C_BUILDING_TRIM = Color(0.55, 0.60, 0.70)
const C_BUILDING_DARK = Color(0.40, 0.44, 0.52)
const C_DOME          = Color(0.72, 0.80, 0.88)
const C_DOME_SHINE    = Color(0.95, 0.97, 1.00, 0.60)
const C_TOWER_BASE    = Color(0.78, 0.80, 0.84)
const C_TOWER_GLASS   = Color(0.45, 0.72, 0.95, 0.80)
const C_SHIP_HULL     = Color(0.90, 0.92, 0.95)
const C_SHIP_DARK     = Color(0.60, 0.64, 0.70)
const C_SHIP_ACCENT   = Color(0.25, 0.55, 0.95)
const C_PALACE_STONE  = Color(0.82, 0.78, 0.70)
const C_PALACE_TRIM   = Color(0.60, 0.50, 0.30)
const C_PALACE_GOLD   = Color(0.90, 0.72, 0.15)
const C_ROAD          = Color(0.58, 0.52, 0.42)
const C_ROAD_LINE     = Color(0.85, 0.80, 0.65, 0.60)
const C_SHADOW        = Color(0.00, 0.00, 0.00, 0.18)
const C_TREE_DARK     = Color(0.18, 0.42, 0.12)
const C_TREE_MID      = Color(0.28, 0.58, 0.18)
const C_TREE_LIGHT    = Color(0.44, 0.76, 0.26)
const C_HILL_BASE     = Color(0.30, 0.55, 0.18)
const C_HILL_LIGHT    = Color(0.44, 0.72, 0.28)

# ── SCENE NODES ───────────────────────────────────────────────
var _camera        : Camera2D    = null
var _player        : Node        = null
var _select_layer  : CanvasLayer = null
var _hud           : CanvasLayer = null
var _cam_zoom_base : float       = 1.1
var _pending_nickname : String   = ""

# Pre-generated decoration data (seeded RNG so it's deterministic)
var _grass_tufts   : Array = []
var _trees         : Array = []
var _road_flowers  : Array = []
var _field_stones  : Array = []

# HUD refs
var _player_name_lbl : Label       = null
var _hp_bar          : ProgressBar = null
var _mp_bar          : ProgressBar = null
var _xp_bar          : ProgressBar = null
var _hp_bar_lbl      : Label       = null
var _mp_bar_lbl      : Label       = null
var _xp_bar_lbl      : Label       = null
var _tgt_panel       : Panel       = null
var _tgt_name_lbl    : Label       = null
var _tgt_hp_bar      : ProgressBar = null
var _player_frame    : Panel       = null
var _frame_drag      : bool        = false

# ── NICKNAME FILTER ───────────────────────────────────────────
const BAD_WORDS : Array = [
	"ass","asshole","bastard","bitch","cock","cunt","damn",
	"dick","douche","fuck","homo","jackass","jerk","moron",
	"nigga","nigger","piss","prick","pussy","shit","slut","twat","whore",
]
func _contains_bad_word(text: String) -> bool:
	for w in BAD_WORDS:
		if text.find(w) >= 0: return true
	return false

# ── MUSIC ─────────────────────────────────────────────────────
var _music : AudioStreamPlayer = null

# ── READY ─────────────────────────────────────────────────────
func _ready() -> void:
	add_to_group("boss_arena_scene")
	add_to_group("ui_layer")
	_gen_decorations()
	_setup_camera()
	_start_music()
	_show_character_select()

func _start_music() -> void:
	var stream = load("res://Sounds/Music/music_battle.mp3") as AudioStream
	if stream == null: return
	_music = AudioStreamPlayer.new()
	_music.stream    = stream
	_music.volume_db = -6.0
	_music.bus       = "Master"
	add_child(_music)
	_music.play()

# ── PROCESS ───────────────────────────────────────────────────
func _process(_delta: float) -> void:
	if is_instance_valid(_player):
		_camera.global_position = _player.global_position
	_update_hud()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_cam_zoom_base = clampf(_cam_zoom_base + 0.1, 0.5, 2.5)
			_camera.zoom = Vector2.ONE * _cam_zoom_base
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_cam_zoom_base = clampf(_cam_zoom_base - 0.1, 0.5, 2.5)
			_camera.zoom = Vector2.ONE * _cam_zoom_base
	if not is_instance_valid(_player): return
	if event is InputEventKey and event.pressed and not event.echo:
		if   event.keycode == KEY_F1: _spawn_dummy()
		elif event.keycode == KEY_F2: _spawn_boss()
		elif event.keycode == KEY_F3: _spawn_cyberlord()
		elif event.keycode == KEY_F4: _spawn_zerg_mob()
		elif event.keycode == KEY_F5: _spawn_cyber_mob()

func _spawn_dummy() -> void:
	var script = load("res://Scripts/TrainingDummy.gd")
	var dummy  = Node2D.new()
	dummy.set_script(script)
	dummy.scale = Vector2(0.7, 0.7)
	var n = get_tree().get_nodes_in_group("training_dummy").size()
	dummy.position = _player.global_position + Vector2(80.0 + n * 50.0, 0.0)
	add_child(dummy)
	dummy.tree_exiting.connect(_on_targetable_removed.bind(dummy))

func _spawn_boss() -> void:
	var script = load("res://Scripts/ZergBoss.gd")
	var boss   = CharacterBody2D.new()
	boss.set_script(script)
	var sprite = AnimatedSprite2D.new()
	sprite.name = "Sprite"; sprite.sprite_frames = _build_boss_frames()
	sprite.scale = Vector2(2.0,2.0); sprite.offset = Vector2(0,-33)
	boss.add_child(sprite)
	var col = CollisionShape2D.new(); var shape = CapsuleShape2D.new()
	shape.radius=52.0; shape.height=90.0; col.shape=shape; boss.add_child(col)
	var n = get_tree().get_nodes_in_group("boss").size()
	var angle = TAU*(float(n)/6.0); var dist = 280.0+n*50.0
	boss.position = _player.global_position + Vector2(cos(angle),sin(angle))*dist
	boss.collision_layer=2; boss.collision_mask=2
	add_child(boss); boss.tree_exiting.connect(_on_targetable_removed.bind(boss))

func _spawn_cyberlord() -> void:
	var script = load("res://Scripts/CyberLord.gd")
	var boss   = CharacterBody2D.new()
	boss.set_script(script)
	var sprite = AnimatedSprite2D.new()
	sprite.name = "Sprite"; sprite.sprite_frames = _build_cyberlord_frames()
	sprite.scale = Vector2(264.0/144.0,264.0/144.0); sprite.offset = Vector2(0,-72)
	boss.add_child(sprite)
	var col = CollisionShape2D.new(); var shape = CapsuleShape2D.new()
	shape.radius=52.0; shape.height=90.0; col.shape=shape; boss.add_child(col)
	var n = get_tree().get_nodes_in_group("boss").size()
	var angle = TAU*(float(n)/6.0); var dist = 280.0+n*50.0
	boss.position = _player.global_position + Vector2(cos(angle),sin(angle))*dist
	boss.collision_layer=2; boss.collision_mask=2
	add_child(boss); boss.tree_exiting.connect(_on_targetable_removed.bind(boss))

func _spawn_zerg_mob() -> void:
	var script = load("res://Scripts/ZergMob.gd")
	var mob = CharacterBody2D.new(); mob.set_script(script)
	var sprite = AnimatedSprite2D.new()
	sprite.name="Sprite"; sprite.sprite_frames=_build_boss_frames()
	sprite.scale=Vector2(1.0,1.0); sprite.offset=Vector2(0,-33)
	mob.add_child(sprite)
	var col=CollisionShape2D.new(); var shape=CapsuleShape2D.new()
	shape.radius=26.0; shape.height=45.0; col.shape=shape; mob.add_child(col)
	var n=get_tree().get_nodes_in_group("mob").size()
	var angle=TAU*(float(n)/8.0); var dist=180.0+n*30.0
	mob.position=_player.global_position+Vector2(cos(angle),sin(angle))*dist
	mob.collision_layer=2; mob.collision_mask=2
	add_child(mob); mob.tree_exiting.connect(_on_targetable_removed.bind(mob))

func _spawn_cyber_mob() -> void:
	var script = load("res://Scripts/CyberMob.gd")
	var mob = CharacterBody2D.new(); mob.set_script(script)
	var sprite = AnimatedSprite2D.new()
	sprite.name="Sprite"; sprite.sprite_frames=_build_cyberlord_frames()
	sprite.scale=Vector2(264.0/144.0*0.5,264.0/144.0*0.5); sprite.offset=Vector2(0,-72)
	mob.add_child(sprite)
	var col=CollisionShape2D.new(); var shape=CapsuleShape2D.new()
	shape.radius=26.0; shape.height=45.0; col.shape=shape; mob.add_child(col)
	var n=get_tree().get_nodes_in_group("mob").size()
	var angle=TAU*(float(n)/8.0); var dist=180.0+n*30.0
	mob.position=_player.global_position+Vector2(cos(angle),sin(angle))*dist
	mob.collision_layer=2; mob.collision_mask=2
	add_child(mob); mob.tree_exiting.connect(_on_targetable_removed.bind(mob))

# ── CAMERA ────────────────────────────────────────────────────
func _setup_camera() -> void:
	_camera             = Camera2D.new()
	_camera.name        = "Camera"
	_camera.position    = Vector2(PORT_X + PORT_W * 0.5, PORT_Y + PORT_H * 0.5)
	_camera.zoom        = Vector2(1.1, 1.1)
	_camera.limit_left  = 0
	_camera.limit_top   = 0
	_camera.limit_right = int(WORLD_W)
	_camera.limit_bottom = int(WORLD_H)
	add_child(_camera)
	_camera.make_current()

# ── PRE-GEN DECORATION DATA ────────────────────────────────────
func _gen_decorations() -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = 1337

	# Grass tufts scattered across the open field (outside spaceport)
	for _i in 1800:
		var gx = rng.randf_range(0, WORLD_W)
		var gy = rng.randf_range(0, WORLD_H)
		# Skip spaceport footprint
		if gx < PORT_X + PORT_W + 60 and gy < PORT_Y + PORT_H + 60:
			continue
		_grass_tufts.append({
			"pos": Vector2(gx, gy),
			"h":   rng.randf_range(4.0, 11.0),
			"w":   rng.randf_range(2.0, 5.0),
			"lean": rng.randf_range(-0.4, 0.4),
			"shade": rng.randf_range(0.0, 1.0),
		})

	# Trees — clusters in the mid-to-far field
	for _i in 420:
		var tx = rng.randf_range(2800, WORLD_W - 100)
		var ty = rng.randf_range(600, WORLD_H - 100)
		_trees.append({
			"pos":  Vector2(tx, ty),
			"r":    rng.randf_range(14.0, 28.0),
			"hue":  rng.randf_range(0.0, 1.0),
		})
	# Some trees along the left edge too (south of spaceport)
	for _i in 80:
		var tx = rng.randf_range(PORT_X, PORT_X + PORT_W * 0.5)
		var ty = rng.randf_range(PORT_Y + PORT_H + 200, WORLD_H - 100)
		_trees.append({
			"pos":  Vector2(tx, ty),
			"r":    rng.randf_range(12.0, 22.0),
			"hue":  rng.randf_range(0.0, 1.0),
		})

	# Small field stones
	for _i in 340:
		var sx = rng.randf_range(400, WORLD_W - 200)
		var sy = rng.randf_range(400, WORLD_H - 200)
		if sx < PORT_X + PORT_W + 100 and sy < PORT_Y + PORT_H + 100:
			continue
		_field_stones.append({
			"pos": Vector2(sx, sy),
			"rx":  rng.randf_range(4.0, 10.0),
			"ry":  rng.randf_range(3.0, 7.0),
			"rot": rng.randf_range(0.0, TAU),
		})

# ============================================================
#  MAIN DRAW
# ============================================================
func _draw() -> void:
	_draw_ground()
	_draw_rivers()
	_draw_field_details()
	_draw_spaceport()

# ── GROUND ────────────────────────────────────────────────────
func _draw_ground() -> void:
	# Base grass fills entire world
	draw_rect(Rect2(0, 0, WORLD_W, WORLD_H), C_GRASS_BASE)

	# Subtle variation stripes — rolling hills effect
	var step = 120.0
	var y = 0.0
	while y < WORLD_H:
		var alpha = 0.06 + sin(y * 0.003) * 0.04
		draw_rect(Rect2(0, y, WORLD_W, step * 0.5), Color(C_GRASS_LIGHT.r, C_GRASS_LIGHT.g, C_GRASS_LIGHT.b, alpha))
		y += step

	# Distant hills along the far edges (top and right)
	_draw_hills()

	# Grass tufts
	for t in _grass_tufts:
		var col = C_GRASS_DARK if t.shade < 0.5 else C_GRASS_LIGHT
		var base = t.pos
		# 3 blades per tuft
		for b in 3:
			var bx = base.x + (b - 1) * t.w * 0.8
			var lean = t.lean + (b - 1) * 0.15
			draw_line(Vector2(bx, base.y),
				Vector2(bx + lean * t.h, base.y - t.h),
				Color(col.r, col.g, col.b, 0.70), 1.2)

	# Field stones
	for s in _field_stones:
		var shd = _ellipse(s.pos + Vector2(2, 4), s.rx * 0.9, s.ry * 0.5, s.rot, 8)
		draw_colored_polygon(shd, C_SHADOW)
		var pts = _ellipse(s.pos, s.rx, s.ry, s.rot, 8)
		draw_colored_polygon(pts, Color(0.65, 0.63, 0.58))
		var hi = _ellipse(s.pos + Vector2(-s.rx*0.2, -s.ry*0.2), s.rx*0.4, s.ry*0.35, s.rot, 6)
		draw_colored_polygon(hi, Color(0.88, 0.86, 0.82, 0.40))

func _draw_hills() -> void:
	# Background hill silhouettes along the top horizon
	var hill_data = [
		[0.0, 220.0, 900.0, 180.0], [700.0, 180.0, 1100.0, 220.0],
		[1500.0, 190.0, 1400.0, 200.0], [2700.0, 160.0, 1600.0, 240.0],
		[4000.0, 200.0, 1200.0, 190.0], [5100.0, 170.0, 1500.0, 210.0],
		[6400.0, 190.0, 1300.0, 200.0], [7400.0, 160.0, 1000.0, 230.0],
		[8800.0, 200.0, 1400.0, 210.0], [10200.0, 175.0, 1600.0, 240.0],
		[11800.0, 185.0, 1200.0, 200.0], [13200.0, 165.0, 1500.0, 220.0],
		[14600.0, 195.0, 1100.0, 190.0],
	]
	for hd in hill_data:
		var pts = PackedVector2Array()
		var hx = hd[0]; var hy = hd[1]; var hw = hd[2]; var hh = hd[3]
		pts.append(Vector2(hx - hw * 0.5, hy))
		var steps = 24
		for i in (steps + 1):
			var t = float(i) / float(steps)
			var px = hx - hw * 0.5 + t * hw
			var py = hy - sin(t * PI) * hh
			pts.append(Vector2(px, py))
		pts.append(Vector2(hx + hw * 0.5, hy))
		draw_colored_polygon(pts, C_HILL_BASE)
		# Lighter top edge
		var top_pts = PackedVector2Array()
		for i in (steps + 1):
			var t = float(i) / float(steps)
			var px = hx - hw * 0.5 + t * hw
			var py = hy - sin(t * PI) * hh
			top_pts.append(Vector2(px, py))
		if top_pts.size() >= 2:
			for i in (top_pts.size() - 1):
				draw_line(top_pts[i], top_pts[i+1], Color(C_HILL_LIGHT.r, C_HILL_LIGHT.g, C_HILL_LIGHT.b, 0.60), 3.0)

# ── ROADS ─────────────────────────────────────────────────────
func _draw_roads() -> void:
	pass   # Roads removed — open world

# ── RIVERS & LAKES ────────────────────────────────────────────
func _draw_rivers() -> void:
	# ── Lake 1 — mid-east region ──────────────────────────────
	var lake1_c = Vector2(WORLD_W * 0.72, WORLD_H * 0.38)
	var lake1_rx = 620.0; var lake1_ry = 390.0
	_draw_lake(lake1_c, lake1_rx, lake1_ry)

	# ── Lake 2 — south-west region ────────────────────────────
	var lake2_c = Vector2(WORLD_W * 0.22, WORLD_H * 0.74)
	var lake2_rx = 500.0; var lake2_ry = 310.0
	_draw_lake(lake2_c, lake2_rx, lake2_ry)

	# ── River A — flows from north, widens into Lake 1 ─────────
	# Starts near the spaceport east edge, winds south-east into lake 1
	_draw_river_segment(
		Vector2(PORT_X + PORT_W + 380, PORT_Y + PORT_H),   # start
		Vector2(lake1_c.x - lake1_rx * 0.6, lake1_c.y),    # end mouth
		28.0, 0.006)

	# ── River B — flows from lake 1 south to lake 2 ────────────
	_draw_river_segment(
		Vector2(lake1_c.x, lake1_c.y + lake1_ry * 0.7),
		Vector2(lake2_c.x + lake2_rx * 0.5, lake2_c.y - lake2_ry * 0.4),
		22.0, 0.005)

	# ── River C — drains lake 2 to west edge ──────────────────
	_draw_river_segment(
		Vector2(lake2_c.x - lake2_rx * 0.8, lake2_c.y),
		Vector2(0, lake2_c.y + 80),
		18.0, 0.007)

func _draw_lake(center: Vector2, rx: float, ry: float) -> void:
	# Deep lake fill — layered for depth effect
	var rng2 = RandomNumberGenerator.new()
	rng2.seed = int(center.x + center.y)
	# Outer shallow water
	var outer = PackedVector2Array()
	for i in 40:
		var a   = float(i)/40.0 * TAU
		var jit = rng2.randf_range(0.92, 1.06)
		outer.append(center + Vector2(cos(a)*rx*jit, sin(a)*ry*jit))
	draw_colored_polygon(outer, Color(0.18, 0.44, 0.72))
	# Mid water
	var mid_pts = PackedVector2Array()
	for i in 36:
		var a   = float(i)/36.0 * TAU
		var jit = rng2.randf_range(0.88, 1.02)
		mid_pts.append(center + Vector2(cos(a)*rx*0.82*jit, sin(a)*ry*0.82*jit))
	draw_colored_polygon(mid_pts, Color(0.15, 0.38, 0.68))
	# Deep centre
	var deep = PackedVector2Array()
	for i in 28:
		var a = float(i)/28.0 * TAU
		deep.append(center + Vector2(cos(a)*rx*0.50, sin(a)*ry*0.50))
	draw_colored_polygon(deep, Color(0.10, 0.28, 0.58))
	# Specular highlight
	var hi_c = center + Vector2(-rx*0.22, -ry*0.18)
	var hi = PackedVector2Array()
	for i in 20:
		var a = float(i)/20.0 * TAU
		hi.append(hi_c + Vector2(cos(a)*rx*0.28, sin(a)*ry*0.16))
	draw_colored_polygon(hi, Color(0.55, 0.78, 1.00, 0.28))
	# Shoreline foam ring
	for i in 40:
		var a0 = float(i)/40.0 * TAU
		var a1 = float(i+1)/40.0 * TAU
		var p0 = center + Vector2(cos(a0)*rx, sin(a0)*ry)
		var p1 = center + Vector2(cos(a1)*rx, sin(a1)*ry)
		draw_line(p0, p1, Color(0.55, 0.80, 1.00, 0.45), 3.0)

func _draw_river_segment(start: Vector2, end_pos: Vector2, width: float, freq: float) -> void:
	# Draw a curving river from start to end using a bezier-like S-curve
	var ctrl_mid = (start + end_pos) * 0.5 + Vector2(
		sin(start.x * 0.0003) * 400.0,
		cos(start.y * 0.0003) * 300.0)
	var segs = 48
	var pts_top = PackedVector2Array()
	var pts_bot = PackedVector2Array()
	for i in (segs + 1):
		var t   = float(i) / segs
		# Quadratic bezier
		var p   = start.lerp(ctrl_mid, t).lerp(ctrl_mid.lerp(end_pos, t), t)
		var tan : Vector2
		if i < segs:
			var t2  = float(i+1)/segs
			var p2  = start.lerp(ctrl_mid,t2).lerp(ctrl_mid.lerp(end_pos,t2),t2)
			tan = (p2 - p).normalized()
		else:
			tan = (end_pos - ctrl_mid).normalized()
		var perp = Vector2(-tan.y, tan.x)
		var w    = width * (0.8 + 0.2 * sin(t * PI))   # slight widening in middle
		var wave = sin(t * 8.0 * PI) * 4.0
		pts_top.append(p + perp * (w + wave))
		pts_bot.append(p - perp * (w - wave))
	# Combine into closed polygon
	var rpts = PackedVector2Array()
	for pt in pts_top: rpts.append(pt)
	for i in range(pts_bot.size()-1, -1, -1): rpts.append(pts_bot[i])
	draw_colored_polygon(rpts, C_RIVER)
	# Foam edges
	for i in (segs):
		draw_line(pts_top[i], pts_top[i+1], C_RIVER_FOAM, 1.8)

# ── FIELD DETAILS ─────────────────────────────────────────────
func _draw_field_details() -> void:
	# Trees
	for t in _trees:
		var r  = t.r
		var h  = t.hue
		# Trunk
		draw_rect(Rect2(t.pos.x - 2.5, t.pos.y - r * 0.3, 5.0, r * 0.5), Color(0.35, 0.22, 0.10))
		# Shadow
		draw_colored_polygon(_ellipse(t.pos + Vector2(r * 0.3, r * 0.2), r * 0.9, r * 0.4, 0.0, 12), C_SHADOW)
		# Dark outer
		draw_colored_polygon(_ellipse(t.pos, r, r * 0.88, 0.0, 14),
			Color(C_TREE_DARK.r, C_TREE_DARK.g * (0.85 + h * 0.15), C_TREE_DARK.b))
		# Bright inner highlight
		draw_colored_polygon(_ellipse(t.pos + Vector2(-r*0.15, -r*0.18), r * 0.58, r * 0.52, 0.0, 12),
			Color(C_TREE_LIGHT.r, C_TREE_LIGHT.g * (0.9 + h * 0.1), C_TREE_LIGHT.b))

# ============================================================
#  SPACEPORT COMPLEX  (top-left)
# ============================================================
func _draw_spaceport() -> void:
	_draw_port_ground()
	_draw_perimeter_wall()
	_draw_docking_pads()
	_draw_ships()
	_draw_control_tower()
	_draw_hangars()
	_draw_palace()
	_draw_port_buildings()
	_draw_port_details()

# ── PORT GROUND ───────────────────────────────────────────────
func _draw_port_ground() -> void:
	# Main tarmac fill
	draw_rect(Rect2(PORT_X, PORT_Y, PORT_W, PORT_H), C_TARMAC)

	# Subtle grid pattern on tarmac
	var grid = 80.0
	var gx = PORT_X
	while gx < PORT_X + PORT_W:
		draw_line(Vector2(gx, PORT_Y), Vector2(gx, PORT_Y + PORT_H),
			Color(C_TARMAC_DARK.r, C_TARMAC_DARK.g, C_TARMAC_DARK.b, 0.25), 1.0)
		gx += grid
	var gy = PORT_Y
	while gy < PORT_Y + PORT_H:
		draw_line(Vector2(PORT_X, gy), Vector2(PORT_X + PORT_W, gy),
			Color(C_TARMAC_DARK.r, C_TARMAC_DARK.g, C_TARMAC_DARK.b, 0.25), 1.0)
		gy += grid

	# Main taxiway — vertical yellow line down the center
	var cx = PORT_X + PORT_W * 0.5
	draw_rect(Rect2(cx - 3, PORT_Y, 6, PORT_H), C_TARMAC_LINE)
	# Horizontal cross taxiway
	var cy = PORT_Y + PORT_H * 0.55
	draw_rect(Rect2(PORT_X, cy - 3, PORT_W, 6), C_TARMAC_LINE)

	# Circular apron around control tower
	var tower_pos = Vector2(PORT_X + PORT_W * 0.5, PORT_Y + PORT_H * 0.42)
	for ring in [200.0, 240.0]:
		draw_arc(tower_pos, ring, 0.0, TAU, 64, C_TARMAC_LINE, 2.5)

# ── PERIMETER WALL ────────────────────────────────────────────
func _draw_perimeter_wall() -> void:
	var wall_t = 14.0
	# Outer wall shadow
	draw_rect(Rect2(PORT_X - 4, PORT_Y - 4, PORT_W + 8, wall_t + 8), C_SHADOW)
	draw_rect(Rect2(PORT_X - 4, PORT_Y + PORT_H - wall_t - 4, PORT_W + 8, wall_t + 8), C_SHADOW)
	draw_rect(Rect2(PORT_X - 4, PORT_Y - 4, wall_t + 8, PORT_H + 8), C_SHADOW)
	draw_rect(Rect2(PORT_X + PORT_W - wall_t - 4, PORT_Y - 4, wall_t + 8, PORT_H + 8), C_SHADOW)
	# Wall faces
	draw_rect(Rect2(PORT_X, PORT_Y, PORT_W, wall_t), C_BUILDING_WALL)
	draw_rect(Rect2(PORT_X, PORT_Y + PORT_H - wall_t, PORT_W, wall_t), C_BUILDING_WALL)
	draw_rect(Rect2(PORT_X, PORT_Y, wall_t, PORT_H), C_BUILDING_WALL)
	draw_rect(Rect2(PORT_X + PORT_W - wall_t, PORT_Y, wall_t, PORT_H), C_BUILDING_WALL)
	# Wall top trim line
	draw_line(Vector2(PORT_X, PORT_Y + wall_t), Vector2(PORT_X + PORT_W, PORT_Y + wall_t),
		Color(C_BUILDING_TRIM.r, C_BUILDING_TRIM.g, C_BUILDING_TRIM.b, 0.5), 2.0)

	# Gate openings — south gate (main road) and east gate
	var south_gate_x = PORT_X + PORT_W * 0.5 - 36.0
	draw_rect(Rect2(south_gate_x, PORT_Y + PORT_H - wall_t, 72.0, wall_t + 2), C_TARMAC)
	draw_rect(Rect2(PORT_X + PORT_W - wall_t, PORT_Y + PORT_H * 0.55 - 36.0, wall_t + 2, 72.0), C_TARMAC)

	# Gate pillars
	for gp in [Vector2(south_gate_x - 12, PORT_Y + PORT_H - wall_t - 16),
				Vector2(south_gate_x + 72, PORT_Y + PORT_H - wall_t - 16)]:
		draw_rect(Rect2(gp.x, gp.y, 12, 30), C_BUILDING_WALL)
		draw_rect(Rect2(gp.x - 2, gp.y - 4, 16, 8), C_BUILDING_TRIM)

# ── DOCKING PADS ──────────────────────────────────────────────
func _draw_docking_pads() -> void:
	# Three large circular landing pads — two on the left bay, one on the right
	var pads = [
		Vector2(PORT_X + 280, PORT_Y + PORT_H * 0.35),   # Left bay ship 1
		Vector2(PORT_X + 280, PORT_Y + PORT_H * 0.68),   # Left bay ship 2
		Vector2(PORT_X + PORT_W * 0.78, PORT_Y + PORT_H * 0.38),  # Right bay
	]
	for pd in pads:
		var r = 130.0
		# Pad shadow
		draw_colored_polygon(_ellipse(pd + Vector2(6, 10), r + 8, r * 0.35, 0.0, 32), C_SHADOW)
		# Outer ring
		draw_colored_polygon(_ellipse(pd, r, r, 0.0, 40), C_TARMAC_DARK)
		# Inner pad
		draw_colored_polygon(_ellipse(pd, r - 14, r - 14, 0.0, 40), Color(0.58, 0.62, 0.68))
		# Yellow chevron ring
		draw_arc(pd, r - 8, 0.0, TAU, 48, C_TARMAC_LINE, 3.0)
		draw_arc(pd, r - 22, 0.0, TAU, 48, Color(C_TARMAC_LINE.r, C_TARMAC_LINE.g, C_TARMAC_LINE.b, 0.50), 1.5)
		# Cardinal docking direction arrows
		for ang in [0.0, PI * 0.5, PI, PI * 1.5]:
			var tip = pd + Vector2(cos(ang), sin(ang)) * (r - 30)
			var bl  = pd + Vector2(cos(ang + 2.4), sin(ang + 2.4)) * (r - 50)
			var br  = pd + Vector2(cos(ang - 2.4), sin(ang - 2.4)) * (r - 50)
			draw_colored_polygon(PackedVector2Array([tip, bl, br]),
				Color(C_TARMAC_LINE.r, C_TARMAC_LINE.g, C_TARMAC_LINE.b, 0.70))

# ── SHIPS ─────────────────────────────────────────────────────
func _draw_ships() -> void:
	# Ship A — sleek triangular fighter on left pad 1
	var sa = Vector2(PORT_X + 280, PORT_Y + PORT_H * 0.35)
	_draw_ship_fighter(sa, 0.0)

	# Ship B — broader transport ship on left pad 2
	var sb = Vector2(PORT_X + 280, PORT_Y + PORT_H * 0.68)
	_draw_ship_transport(sb, 0.15)

	# Ship C — long freighter on right pad
	var sc = Vector2(PORT_X + PORT_W * 0.78, PORT_Y + PORT_H * 0.38)
	_draw_ship_fighter(sc, PI * 0.25)

func _draw_ship_fighter(pos: Vector2, rot: float) -> void:
	# Shadow
	draw_colored_polygon(_ellipse(pos + Vector2(8, 14), 110, 28, rot, 16), C_SHADOW)
	# Main hull — elongated teardrop pointing in rot direction
	var fwd = Vector2(cos(rot), sin(rot))
	var side = Vector2(-sin(rot), cos(rot))
	var nose = pos + fwd * 100
	var tail = pos - fwd * 85
	var pts  = PackedVector2Array()
	var n    = 20
	for i in (n + 1):
		var t  = float(i) / float(n)
		var px : float
		var py : float
		if t <= 0.5:
			# Nose half — narrow
			px = lerpf(-85, 100, t * 2.0) * 1.0
			py = sin(t * 2.0 * PI) * 32.0
		else:
			# Tail half — wider
			px = lerpf(100, -85, (t - 0.5) * 2.0)
			py = -sin((t - 0.5) * 2.0 * PI) * 32.0
		pts.append(pos + fwd * px + side * py)
	draw_colored_polygon(pts, C_SHIP_HULL)
	# Cockpit glass dome
	var cockpit_pts = _ellipse(pos + fwd * 30, 26, 14, rot, 14)
	draw_colored_polygon(cockpit_pts, C_TOWER_GLASS)
	draw_colored_polygon(_ellipse(pos + fwd * 32 + side * (-6), 10, 5, rot, 10),
		Color(1.0, 1.0, 1.0, 0.55))
	# Engine nacelles
	for side_m in [-1.0, 1.0]:
		var eng_pos = pos - fwd * 60 + side * side_m * 26
		draw_colored_polygon(_ellipse(eng_pos, 18, 10, rot, 10), C_SHIP_DARK)
		draw_colored_polygon(_ellipse(eng_pos - fwd * 18, 10, 9, rot, 10), Color(0.35, 0.70, 1.0, 0.80))
	# Hull accent stripe
	draw_line(pos - fwd * 80 + side * 8, pos + fwd * 80 + side * 8, C_SHIP_ACCENT, 3.0)
	draw_line(pos - fwd * 80 - side * 8, pos + fwd * 80 - side * 8, C_SHIP_ACCENT, 3.0)

func _draw_ship_transport(pos: Vector2, rot: float) -> void:
	var fwd  = Vector2(cos(rot), sin(rot))
	var side = Vector2(-sin(rot), cos(rot))
	# Shadow
	draw_colored_polygon(_ellipse(pos + Vector2(10, 16), 95, 48, rot, 16), C_SHADOW)
	# Wide boxy hull
	var hull = PackedVector2Array([
		pos - fwd * 90 - side * 44,
		pos + fwd * 70 - side * 30,
		pos + fwd * 90 + side * 0,
		pos + fwd * 70 + side * 30,
		pos - fwd * 90 + side * 44,
	])
	draw_colored_polygon(hull, C_SHIP_HULL)
	# Top superstructure
	var super_hull = PackedVector2Array([
		pos - fwd * 50 - side * 20,
		pos + fwd * 40 - side * 15,
		pos + fwd * 40 + side * 15,
		pos - fwd * 50 + side * 20,
	])
	draw_colored_polygon(super_hull, C_BUILDING_WALL)
	# Bridge windows
	for wi in 4:
		var wp = pos + fwd * (10 + wi * 10) + side * (-12 + wi * 2)
		draw_circle(wp, 4.5, C_TOWER_GLASS)
	# Cargo dome on top
	draw_colored_polygon(_ellipse(pos - fwd * 20, 30, 18, rot, 14), C_DOME)
	draw_colored_polygon(_ellipse(pos - fwd * 18, 14, 8, rot, 10), C_DOME_SHINE)
	# Accent
	draw_line(pos - fwd * 80, pos + fwd * 80, C_SHIP_ACCENT, 2.0)

# ── CONTROL TOWER ─────────────────────────────────────────────
func _draw_control_tower() -> void:
	var tx = PORT_X + PORT_W * 0.5
	var ty = PORT_Y + PORT_H * 0.42
	var tp = Vector2(tx, ty)

	# ── Base platform ──────────────────────────────────────────
	# Shadow
	draw_colored_polygon(_ellipse(tp + Vector2(8, 14), 90, 30, 0.0, 24), C_SHADOW)
	draw_colored_polygon(_ellipse(tp, 84, 30, 0.0, 32), C_BUILDING_TRIM)
	draw_colored_polygon(_ellipse(tp, 78, 26, 0.0, 32), C_BUILDING_WALL)
	# Outer ring detail
	draw_arc(tp, 78, 0.0, TAU, 40, C_BUILDING_TRIM, 3.0)

	# ── Tower shaft — wide at base, tapers upward ──────────────
	# Drawn as a trapezoid going upward
	var shaft_pts = PackedVector2Array([
		Vector2(tx - 28, ty),
		Vector2(tx + 28, ty),
		Vector2(tx + 18, ty - 220),
		Vector2(tx - 18, ty - 220),
	])
	draw_colored_polygon(shaft_pts, C_TOWER_BASE)
	# Highlight / shading side panels
	var left_face = PackedVector2Array([
		Vector2(tx - 28, ty), Vector2(tx - 18, ty - 220),
		Vector2(tx - 12, ty - 220), Vector2(tx - 22, ty),
	])
	draw_colored_polygon(left_face, Color(C_BUILDING_DARK.r, C_BUILDING_DARK.g, C_BUILDING_DARK.b, 0.35))
	# Horizontal band details on shaft
	for band_y in [ty - 55, ty - 110, ty - 165]:
		draw_rect(Rect2(tx - 20, band_y, 40, 6), C_BUILDING_TRIM)

	# ── Mid observation deck ───────────────────────────────────
	var deck_y = ty - 220
	var deck_pts = PackedVector2Array([
		Vector2(tx - 52, deck_y + 4),
		Vector2(tx + 52, deck_y + 4),
		Vector2(tx + 46, deck_y - 26),
		Vector2(tx - 46, deck_y - 26),
	])
	draw_colored_polygon(deck_pts, C_BUILDING_WALL)
	draw_rect(Rect2(tx - 52, deck_y - 26, 104, 4), C_BUILDING_TRIM)
	draw_rect(Rect2(tx - 52, deck_y + 4, 104, 4), C_BUILDING_TRIM)

	# ── Upper control room — glass dome ───────────────────────
	var top_y = deck_y - 26
	# Neck piece
	var neck = PackedVector2Array([
		Vector2(tx - 16, top_y),
		Vector2(tx + 16, top_y),
		Vector2(tx + 12, top_y - 35),
		Vector2(tx - 12, top_y - 35),
	])
	draw_colored_polygon(neck, C_TOWER_BASE)

	# Glass orb — the iconic control room
	var orb_c = Vector2(tx, top_y - 68)
	draw_colored_polygon(_ellipse(orb_c + Vector2(4, 6), 44, 16, 0.0, 20), C_SHADOW)
	draw_colored_polygon(_ellipse(orb_c, 44, 44, 0.0, 36), C_TOWER_GLASS)
	# Glass reflection
	draw_colored_polygon(_ellipse(orb_c + Vector2(-12, -14), 18, 12, -0.4, 12),
		Color(1.0, 1.0, 1.0, 0.45))
	# Rim
	draw_arc(orb_c, 44, 0.0, TAU, 36, C_BUILDING_TRIM, 2.5)
	# Antenna mast
	draw_line(orb_c, orb_c - Vector2(0, 52), C_BUILDING_DARK, 3.0)
	draw_circle(orb_c - Vector2(0, 52), 5.0, Color(1.0, 0.30, 0.20))   # red beacon
	# Cross antenna arms
	for ang in [0.0, PI * 0.5, PI, PI * 1.5]:
		draw_line(orb_c - Vector2(0, 40),
			orb_c - Vector2(0, 40) + Vector2(cos(ang), sin(ang)) * 14.0,
			C_BUILDING_DARK, 2.0)

	# ── Spotlights on the deck railing ────────────────────────
	for sl in [-40.0, -20.0, 20.0, 40.0]:
		draw_circle(Vector2(tx + sl, deck_y - 22), 4.0, Color(1.0, 0.92, 0.60))
		draw_circle(Vector2(tx + sl, deck_y - 22), 2.0, Color(1.0, 1.0, 1.0))

# ── HANGARS ───────────────────────────────────────────────────
func _draw_hangars() -> void:
	# Two large hangar buildings on the left side of the port
	var hangar_data = [
		Vector2(PORT_X + 80, PORT_Y + 220),   # upper left
		Vector2(PORT_X + 80, PORT_Y + 800),   # lower left
	]
	for hp in hangar_data:
		var hw = 360.0; var hh = 280.0
		# Shadow
		draw_rect(Rect2(hp.x + 8, hp.y + 12, hw, hh), C_SHADOW)
		# Wall
		draw_rect(Rect2(hp.x, hp.y, hw, hh), C_BUILDING_WALL)
		# Roof dome — barrel vault shape
		var vault_pts = PackedVector2Array()
		var vsteps = 24
		for i in (vsteps + 1):
			var t = float(i) / float(vsteps)
			vault_pts.append(Vector2(hp.x + t * hw, hp.y - sin(t * PI) * 55.0))
		vault_pts.append(Vector2(hp.x + hw, hp.y))
		vault_pts.append(Vector2(hp.x, hp.y))
		draw_colored_polygon(vault_pts, C_DOME)
		# Dome shine strip
		var shine = PackedVector2Array()
		for i in (vsteps + 1):
			var t = float(i) / float(vsteps)
			shine.append(Vector2(hp.x + hw * 0.2 + t * hw * 0.6, hp.y - sin(t * PI) * 54.0))
		for i in range(vsteps, -1, -1):
			var t = float(i) / float(vsteps)
			shine.append(Vector2(hp.x + hw * 0.25 + t * hw * 0.5, hp.y - sin(t * PI) * 44.0))
		draw_colored_polygon(shine, C_DOME_SHINE)
		# Front face trim
		draw_rect(Rect2(hp.x, hp.y, hw, 8), C_BUILDING_TRIM)
		# Large hangar bay door opening
		var door_x = hp.x + hw * 0.25
		var door_w = hw * 0.5; var door_h = hh * 0.65
		draw_rect(Rect2(door_x, hp.y + hh - door_h, door_w, door_h), C_BUILDING_DARK)
		draw_rect(Rect2(door_x, hp.y + hh - door_h, door_w, 6), C_BUILDING_TRIM)
		# Door frame
		draw_rect(Rect2(door_x - 6, hp.y + hh - door_h - 6, 6, door_h + 6), C_BUILDING_TRIM)
		draw_rect(Rect2(door_x + door_w, hp.y + hh - door_h - 6, 6, door_h + 6), C_BUILDING_TRIM)
		# Side windows
		for wx in [hp.x + 20, hp.x + hw - 40]:
			draw_rect(Rect2(wx, hp.y + hh * 0.2, 18, 28), C_TOWER_GLASS)
			draw_line(Vector2(wx + 9, hp.y + hh * 0.2),
				Vector2(wx + 9, hp.y + hh * 0.2 + 28), C_BUILDING_TRIM, 1.5)

# ── PALACE ────────────────────────────────────────────────────
func _draw_palace() -> void:
	# Political Palace — impressive building on the right side of the spaceport
	var px = PORT_X + PORT_W * 0.58
	var py = PORT_Y + PORT_H * 0.55
	var pw = 580.0; var ph = 480.0

	# Grand plaza approach (courtyard in front)
	draw_rect(Rect2(px - 30, py - 60, pw + 60, 60), Color(0.72, 0.68, 0.60))

	# Shadow
	draw_rect(Rect2(px + 10, py + 14, pw, ph), C_SHADOW)

	# Main body
	draw_rect(Rect2(px, py, pw, ph), C_PALACE_STONE)

	# Colonnade facade — series of columns across the front
	var col_count = 10
	var col_spacing = pw / (col_count + 1)
	for ci in col_count:
		var col_x = px + col_spacing * (ci + 1) - 7
		# Column shadow
		draw_rect(Rect2(col_x + 3, py - 80, 14, 90), C_SHADOW)
		# Column shaft
		draw_rect(Rect2(col_x, py - 80, 14, 90), C_PALACE_STONE)
		# Capital
		draw_rect(Rect2(col_x - 4, py - 84, 22, 8), C_PALACE_TRIM)
		# Base
		draw_rect(Rect2(col_x - 3, py - 2, 20, 6), C_PALACE_TRIM)

	# Roof pediment
	var ped_pts = PackedVector2Array([
		Vector2(px - 20, py - 80),
		Vector2(px + pw + 20, py - 80),
		Vector2(px + pw * 0.5, py - 160),
	])
	draw_colored_polygon(ped_pts, C_PALACE_STONE)
	draw_polyline(PackedVector2Array([
		Vector2(px - 20, py - 80),
		Vector2(px + pw * 0.5, py - 160),
		Vector2(px + pw + 20, py - 80),
	]), C_PALACE_TRIM, 4.0)

	# Gold trim along roofline
	draw_line(Vector2(px - 20, py - 80), Vector2(px + pw + 20, py - 80), C_PALACE_GOLD, 5.0)
	draw_line(Vector2(px, py), Vector2(px + pw, py), C_PALACE_GOLD, 3.0)
	draw_line(Vector2(px, py + ph), Vector2(px + pw, py + ph), C_PALACE_TRIM, 3.0)

	# Central entrance — grand archway
	var arch_x = px + pw * 0.5 - 38
	var arch_w  = 76.0; var arch_h = 110.0
	draw_rect(Rect2(arch_x, py + ph - arch_h, arch_w, arch_h), C_BUILDING_DARK)
	# Arch curve
	var arch_pts = PackedVector2Array()
	var arch_cx = arch_x + arch_w * 0.5
	var arch_top = py + ph - arch_h
	for i in 17:
		var ang = PI + float(i) / 16.0 * PI
		arch_pts.append(Vector2(arch_cx + cos(ang) * arch_w * 0.5, arch_top + sin(ang) * arch_w * 0.5 + arch_w * 0.5))
	arch_pts.append(Vector2(arch_x + arch_w, arch_top + arch_w * 0.5))
	arch_pts.append(Vector2(arch_x, arch_top + arch_w * 0.5))
	draw_colored_polygon(arch_pts, C_BUILDING_DARK)
	draw_polyline(arch_pts, C_PALACE_GOLD, 3.0)

	# Flanking towers with domes
	for side_x in [px + 20, px + pw - 80]:
		draw_rect(Rect2(side_x, py - 120, 60, 120 + ph * 0.7), C_PALACE_STONE)
		draw_rect(Rect2(side_x - 6, py - 122, 72, 10), C_PALACE_TRIM)
		# Tower dome
		var dome_cx = Vector2(side_x + 30, py - 130)
		draw_colored_polygon(_ellipse(dome_cx, 36, 36, 0.0, 24), C_DOME)
		draw_colored_polygon(_ellipse(dome_cx + Vector2(-8, -8), 14, 10, 0.0, 12), C_DOME_SHINE)
		draw_arc(dome_cx, 36, 0.0, TAU, 24, C_PALACE_TRIM, 2.0)
		# Tower flag
		draw_line(dome_cx, dome_cx - Vector2(0, 40), C_BUILDING_DARK, 2.5)
		var flag_pts = PackedVector2Array([
			dome_cx - Vector2(0, 40),
			dome_cx - Vector2(-28, 30),
			dome_cx - Vector2(-2, 20),
		])
		draw_colored_polygon(flag_pts, Color(0.85, 0.15, 0.15))   # red flag
		# Tower windows
		for wy in [py - 90, py - 50, py + 10, py + 70]:
			draw_rect(Rect2(side_x + 18, wy, 24, 30), C_TOWER_GLASS)
			draw_arc(Vector2(side_x + 30, wy), 12, PI, TAU, 10, C_PALACE_TRIM, 1.5)

	# Facade windows
	for row in 3:
		for col in 7:
			var wx = px + 60 + col * 66
			var wy = py + 40 + row * 110
			if abs(wx - (px + pw * 0.5)) < 55: continue   # skip center door area
			draw_rect(Rect2(wx, wy, 28, 38), C_TOWER_GLASS)
			draw_arc(Vector2(wx + 14, wy), 14, PI, TAU, 8, C_PALACE_TRIM, 1.5)

	# Nameplate above entrance
	var font = ThemeDB.fallback_font
	draw_string(font, Vector2(px + pw * 0.5 - 78, py - 92),
		"IMPERIAL PALACE", HORIZONTAL_ALIGNMENT_LEFT, -1, 13,
		C_PALACE_GOLD)

# ── PORT BUILDINGS — smaller utility buildings ─────────────────
func _draw_port_buildings() -> void:
	# Fuel depot — right side north
	var fd_x = PORT_X + PORT_W * 0.68
	var fd_y = PORT_Y + 120.0
	_draw_box_building(Vector2(fd_x, fd_y), 140.0, 110.0, Color(0.80, 0.76, 0.68), C_BUILDING_TRIM)
	# Fuel tanks — 3 cylindrical tanks
	for ti in 3:
		var tank_c = Vector2(fd_x - 20 + ti * 50, fd_y - 35)
		draw_colored_polygon(_ellipse(tank_c + Vector2(4, 6), 20, 7, 0.0, 14), C_SHADOW)
		draw_colored_polygon(_ellipse(tank_c, 20, 20, 0.0, 20), Color(0.70, 0.72, 0.76))
		draw_colored_polygon(_ellipse(tank_c, 10, 10, 0.0, 14), C_DOME_SHINE)
		draw_arc(tank_c, 20, 0.0, TAU, 20, Color(0.50, 0.55, 0.60), 2.0)

	# Customs office — south of tower, on left
	var co_x = PORT_X + 100; var co_y = PORT_Y + PORT_H * 0.78
	_draw_box_building(Vector2(co_x, co_y), 180.0, 130.0, C_BUILDING_WALL, C_BUILDING_TRIM)
	var font = ThemeDB.fallback_font
	draw_string(font, Vector2(co_x + 14, co_y + 28), "CUSTOMS", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, C_BUILDING_DARK)

	# Small maintenance depot
	var md_x = PORT_X + PORT_W * 0.72; var md_y = PORT_Y + PORT_H * 0.75
	_draw_box_building(Vector2(md_x, md_y), 130.0, 90.0, Color(0.75, 0.70, 0.62), C_BUILDING_TRIM)

func _draw_box_building(pos: Vector2, w: float, h: float, wall_col: Color, trim_col: Color) -> void:
	draw_rect(Rect2(pos.x + 6, pos.y + 10, w, h), C_SHADOW)
	draw_rect(Rect2(pos.x, pos.y, w, h), wall_col)
	draw_rect(Rect2(pos.x, pos.y, w, 8), trim_col)
	draw_rect(Rect2(pos.x, pos.y + h - 6, w, 6), trim_col)
	draw_rect(Rect2(pos.x, pos.y, 6, h), trim_col)
	draw_rect(Rect2(pos.x + w - 6, pos.y, 6, h), trim_col)
	# Door
	draw_rect(Rect2(pos.x + w * 0.5 - 12, pos.y + h - 28, 24, 28), C_BUILDING_DARK)
	# Window
	draw_rect(Rect2(pos.x + 14, pos.y + 14, 22, 18), C_TOWER_GLASS)

# ── PORT DETAILS — small human-scale props ────────────────────
func _draw_port_details() -> void:
	# Ground vehicles / speeders — tiny shapes on the tarmac
	var vehicles = [
		Vector2(PORT_X + 180, PORT_Y + PORT_H * 0.50),
		Vector2(PORT_X + PORT_W * 0.60, PORT_Y + PORT_H * 0.20),
		Vector2(PORT_X + PORT_W * 0.70, PORT_Y + PORT_H * 0.70),
	]
	for vp2 in vehicles:
		draw_rect(Rect2(vp2.x - 12, vp2.y - 6, 24, 12), Color(0.85, 0.88, 0.92))
		draw_rect(Rect2(vp2.x - 8,  vp2.y - 4, 16,  8), Color(0.30, 0.55, 0.90, 0.70))
		draw_circle(Vector2(vp2.x - 7, vp2.y + 6), 4.0, Color(0.15, 0.15, 0.15))
		draw_circle(Vector2(vp2.x + 7, vp2.y + 6), 4.0, Color(0.15, 0.15, 0.15))

	# Tiny NPC figures standing around
	var npcs = [
		Vector2(PORT_X + 200, PORT_Y + PORT_H * 0.52),
		Vector2(PORT_X + 220, PORT_Y + PORT_H * 0.52),
		Vector2(PORT_X + PORT_W * 0.55, PORT_Y + PORT_H * 0.65),
		Vector2(PORT_X + PORT_W * 0.57, PORT_Y + PORT_H * 0.65),
		Vector2(PORT_X + PORT_W * 0.59, PORT_Y + PORT_H * 0.65),
	]
	for np2 in npcs:
		draw_circle(np2 - Vector2(0, 12), 5.0, Color(0.85, 0.72, 0.58))   # head
		draw_rect(Rect2(np2.x - 4, np2.y - 8, 8, 12), Color(0.40, 0.45, 0.55))   # body
		draw_line(np2 - Vector2(0, 8), np2 + Vector2(0, 8), Color(0.30, 0.35, 0.45), 2.0)

	# Lighting poles along taxiway
	var pole_y = PORT_Y + 40.0
	while pole_y < PORT_Y + PORT_H - 40:
		for px2 in [PORT_X + PORT_W * 0.5 - 24, PORT_X + PORT_W * 0.5 + 24]:
			draw_line(Vector2(px2, pole_y), Vector2(px2, pole_y - 30), C_BUILDING_DARK, 2.0)
			draw_circle(Vector2(px2, pole_y - 30), 4.5, Color(1.0, 0.95, 0.70))
		pole_y += 140.0

	# "CORONET SPACEPORT" signage above north wall
	var font = ThemeDB.fallback_font
	draw_string(font, Vector2(PORT_X + PORT_W * 0.5 - 100, PORT_Y + 55),
		"CORONET SPACEPORT", HORIZONTAL_ALIGNMENT_LEFT, -1, 14,
		Color(C_TARMAC_LINE.r, C_TARMAC_LINE.g, C_TARMAC_LINE.b, 0.90))

# ============================================================
#  CHARACTER SELECT  (copied verbatim from BossArenaScene)
# ============================================================
func _show_character_select() -> void:
	_select_layer       = CanvasLayer.new()
	_select_layer.layer = 20
	add_child(_select_layer)

	var vp = get_viewport().get_visible_rect().size

	var bg       = ColorRect.new()
	bg.size      = vp
	bg.color     = Color(0.04, 0.05, 0.12, 0.96)
	_select_layer.add_child(bg)

	var title = Label.new()
	title.text = "CORONET SPACEPORT  —  CHOOSE YOUR CLASS"
	title.add_theme_font_size_override("font_size", 36)
	title.add_theme_color_override("font_color", Color(0.85, 0.92, 1.0))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.size     = Vector2(vp.x, 55)
	title.position = Vector2(0, vp.y * 0.12)
	_select_layer.add_child(title)

	var hint = Label.new()
	hint.text = "WASD / Arrow Keys to move  ·  Tab to cycle targets  ·  Auto-attack in range  ·  P for Skills  ·  I for Inventory"
	hint.add_theme_font_size_override("font_size", 13)
	hint.add_theme_color_override("font_color", Color(0.55, 0.65, 0.75))
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.size     = Vector2(vp.x, 24)
	hint.position = Vector2(0, vp.y * 0.12 + 62)
	_select_layer.add_child(hint)

	var classes = [
		{ "key":"melee",   "label":"MELEE",   "color":Color(0.90,0.35,0.20), "desc":"Close-range brawler.\nGets in your face\nand hits hard.\n\nHP: 300\nAtk every: 2s\nRange: 130px" },
		{ "key":"ranged",  "label":"RANGED",  "color":Color(0.35,0.80,0.95), "desc":"Long-range marksman.\nKeep your distance\nand chip away.\n\nHP: 180\nAtk every: 4s\nRange: 700px" },
		{ "key":"mage",    "label":"MAGE",    "color":Color(0.75,0.42,1.00), "desc":"Arcane spellcaster.\nHigh damage, low HP.\nStay far back.\n\nHP: 150\nAtk every: 4s\nRange: 400px" },
		{ "key":"brawler", "label":"BRAWLER", "color":Color(0.40,0.85,0.30), "desc":"Heavyweight bruiser.\nAbsorbs punishment\nand hits harder.\n\nHP: 350\nAtk every: 2s\nRange: 130px" },
	]

	var card_w  = 210.0; var card_h  = 300.0; var gap = 44.0
	var total_w = card_w * classes.size() + gap * (classes.size() - 1)
	var start_x = (vp.x - total_w) * 0.5
	var card_y  = vp.y * 0.30

	var select_buttons : Array = []
	for i in classes.size():
		var b = _build_class_card(classes[i], Vector2(start_x + i * (card_w + gap), card_y), Vector2(card_w, card_h))
		b.disabled = true
		select_buttons.append(b)

	# Nickname field
	var nick_bg          = ColorRect.new()
	nick_bg.color        = Color(0.05, 0.06, 0.14, 0.92)
	nick_bg.size         = Vector2(340, 50)
	nick_bg.position     = Vector2(vp.x * 0.5 - 170, card_y + card_h + 22.0)
	_select_layer.add_child(nick_bg)

	var nick_lbl = Label.new()
	nick_lbl.text = "NICKNAME:"
	nick_lbl.add_theme_font_size_override("font_size", 13)
	nick_lbl.add_theme_color_override("font_color", Color(0.55, 0.80, 1.0))
	nick_lbl.position = Vector2(10, 13); nick_lbl.size = Vector2(105, 24)
	nick_bg.add_child(nick_lbl)

	var nick_field = LineEdit.new()
	nick_field.name             = "NickField"
	nick_field.max_length       = 20
	nick_field.placeholder_text = "enter nickname..."
	nick_field.position = Vector2(118, 7); nick_field.size = Vector2(212, 36)
	nick_field.add_theme_font_size_override("font_size", 14)
	nick_field.add_theme_color_override("font_color", Color(1,1,1))
	nick_field.add_theme_color_override("font_placeholder_color", Color(0.4,0.4,0.45))
	var ns = StyleBoxFlat.new()
	ns.bg_color = Color(0.08,0.06,0.14); ns.border_color = Color(0.35,0.55,0.90,0.60)
	ns.set_border_width_all(1)
	nick_field.add_theme_stylebox_override("normal", ns)
	nick_field.add_theme_stylebox_override("focus",  ns)
	nick_bg.add_child(nick_field)

	var cfg = ConfigFile.new()
	if cfg.load("user://player_prefs.cfg") == OK:
		var saved = cfg.get_value("player", "nickname", "")
		if saved.length() > 0 and not _contains_bad_word(saved.to_lower()):
			nick_field.text = saved
			for b in select_buttons: b.disabled = false

	var nick_hint = Label.new()
	nick_hint.name = "NickHint"; nick_hint.text = "Enter a nickname to continue."
	nick_hint.add_theme_font_size_override("font_size", 11)
	nick_hint.add_theme_color_override("font_color", Color(0.9,0.5,0.3))
	nick_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	nick_hint.size = Vector2(vp.x, 18); nick_hint.position = Vector2(0, card_y + card_h + 76.0)
	nick_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_select_layer.add_child(nick_hint)

	nick_field.text_changed.connect(func(text:String) -> void:
		var clean = text.strip_edges()
		if clean.length() == 0:
			nick_hint.text = "Enter a nickname to continue."
			for b in select_buttons: b.disabled = true
		elif _contains_bad_word(clean.to_lower()):
			nick_hint.text = "That nickname is not allowed."
			for b in select_buttons: b.disabled = true
		else:
			nick_hint.text = ""
			for b in select_buttons: b.disabled = false
	)

func _build_class_card(cls: Dictionary, pos: Vector2, sz: Vector2) -> Button:
	var panel      = Panel.new()
	panel.position = pos; panel.size = sz
	var sty        = StyleBoxFlat.new()
	sty.bg_color   = Color(0.06, 0.07, 0.16, 0.92)
	sty.border_color = cls.color
	sty.set_border_width_all(2); sty.set_corner_radius_all(6)
	panel.add_theme_stylebox_override("panel", sty)
	_select_layer.add_child(panel)

	var lbl = Label.new()
	lbl.text = cls.label
	lbl.add_theme_font_size_override("font_size", 22)
	lbl.add_theme_color_override("font_color", cls.color)
	lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lbl.size = Vector2(sz.x, 36); lbl.position = Vector2(0, 16)
	panel.add_child(lbl)

	var desc = Label.new()
	desc.text = cls.desc
	desc.add_theme_font_size_override("font_size", 13)
	desc.add_theme_color_override("font_color", Color(0.80, 0.82, 0.88))
	desc.size = Vector2(sz.x - 20, sz.y - 110); desc.position = Vector2(10, 58)
	panel.add_child(desc)

	var btn           = Button.new()
	btn.text          = "PLAY AS " + cls.label
	btn.size          = Vector2(sz.x - 20, 40)
	btn.position      = Vector2(10, sz.y - 50)
	btn.add_theme_font_size_override("font_size", 13)
	btn.add_theme_color_override("font_color", cls.color)
	var bsty          = StyleBoxFlat.new()
	bsty.bg_color     = Color(0.08, 0.06, 0.18)
	bsty.border_color = cls.color
	bsty.set_border_width_all(1); bsty.set_corner_radius_all(4)
	btn.add_theme_stylebox_override("normal", bsty)
	btn.pressed.connect(_on_class_selected.bind(cls.key))
	panel.add_child(btn)
	return btn

func _on_class_selected(cls: String) -> void:
	# Save nickname
	var nick_field = _select_layer.get_node_or_null("NickBg/NickField")
	if nick_field == null:
		# Find it anywhere in the layer
		for ch in _select_layer.get_children():
			var nf = ch.get_node_or_null("NickField")
			if nf: nick_field = nf; break
	var nick = ""
	if nick_field: nick = nick_field.text.strip_edges()
	if nick.length() > 0 and not _contains_bad_word(nick.to_lower()):
		_pending_nickname = nick
		var cfg = ConfigFile.new()
		cfg.set_value("player", "nickname", nick)
		cfg.save("user://player_prefs.cfg")

	_select_layer.queue_free()
	_select_layer = null
	_spawn_player(cls)
	_spawn_shop_terminal()
	_setup_hud(cls)
	_spawn_teleporters()

# ── PLAYER SPAWN ──────────────────────────────────────────────
func _spawn_player(cls: String) -> void:
	var script = load("res://Scripts/BossArenaPlayer.gd")
	_player    = CharacterBody2D.new()
	_player.set_script(script)
	_player.set("character_class", cls)

	var sprite          = AnimatedSprite2D.new()
	sprite.name         = "Sprite"
	sprite.sprite_frames = _build_frames(cls)
	if cls == "brawler":
		sprite.scale  = Vector2(44.0 / 144.0, 44.0 / 144.0)
		sprite.offset = Vector2(0, -72)
	elif cls == "ranged":
		sprite.scale  = Vector2(1.0, 1.0)
		sprite.offset = Vector2(0, -16)
	else:
		sprite.scale  = Vector2(1.0, 1.0)
		sprite.offset = Vector2(0, -12)
	_player.add_child(sprite)

	var col   = CollisionShape2D.new()
	var shape = CapsuleShape2D.new()
	shape.radius = 12.0; shape.height = 20.0
	col.shape = shape
	_player.add_child(col)

	# Spawn inside the spaceport near the south gate
	_player.position = Vector2(PORT_X + PORT_W * 0.5, PORT_Y + PORT_H * 0.88)
	add_child(_player)
	if _pending_nickname.length() > 0:
		_player.set("character_name", _pending_nickname)

func _spawn_shop_terminal() -> void:
	var script   = load("res://Scripts/BossShopTerminal.gd")
	var terminal = Node2D.new()
	terminal.set_script(script)
	# Place next to player spawn, near customs office
	terminal.position = Vector2(PORT_X + PORT_W * 0.5 + 90, PORT_Y + PORT_H * 0.88)
	add_child(terminal)

# ── TELEPORTERS ───────────────────────────────────────────────
const SPAWN_POS : Vector2 = Vector2(PORT_X + PORT_W * 0.5, PORT_Y + PORT_H * 0.88)

func _spawn_teleporters() -> void:
	var tp_script = load("res://Scripts/SpaceportTeleporter.gd")

	# Teleporter #1 — outside the south gate, just off the main road
	# Players will find this when leaving the spaceport heading south
	var tp1       = Node2D.new()
	tp1.set_script(tp_script)
	tp1.position  = Vector2(PORT_X + PORT_W * 0.5, PORT_Y + PORT_H + 180.0)
	add_child(tp1)
	tp1.call("init", _player, "tp_spaceport_south", [
		{ "label": "Coronet Spaceport — Main Gate", "pos": SPAWN_POS },
	])

# ── SPRITE FRAMES (identical to BossArenaScene) ───────────────
func _build_frames(cls: String) -> SpriteFrames:
	var frames = SpriteFrames.new()
	if frames.has_animation("default"):
		frames.remove_animation("default")
	match cls:
		"melee":
			var base = "res://Characters/minimmo/melee/"
			for dir in ["s","n","e","w"]:
				_add_strip(frames,"idle_"+dir,  base+"idle/idle_"+dir+".png",   24,24,8,8.0)
				_add_strip(frames,"run_"+dir,   base+"run/run_"+dir+".png",    24,24,4,10.0)
				_add_strip(frames,"attack_"+dir,base+"attack/attack_"+dir+".png",24,24,6,12.0,false)
		"mage":
			var base = "res://Characters/minimmo/mage/"
			for dir in ["s","n","e","w"]:
				_add_strip(frames,"idle_"+dir,  base+"idle/idle_"+dir+".png",   24,24,8,8.0)
				_add_strip(frames,"run_"+dir,   base+"run/run_"+dir+".png",    24,24,4,10.0)
				_add_strip(frames,"attack_"+dir,base+"attack/attack_"+dir+".png",24,24,6,12.0,false)
		"ranged":
			var base = "res://Characters/minimmo/ranged/"
			for dir in ["s","n","e","w"]:
				_add_strip(frames,"idle_"+dir,  base+"idle/idle_"+dir+".png",   24,24,8,8.0)
				_add_strip(frames,"run_"+dir,   base+"run/run_"+dir+".png",    24,24,8,10.0)
				_add_strip(frames,"attack_"+dir,base+"attack/attack_"+dir+".png",32,32,16,14.0,false)
		"brawler":
			var base = "res://Characters/minimmo/melee2/"
			for dir in ["s","n","e","w"]:
				_add_strip(frames,"idle_"+dir,  base+"idle/idle_"+dir+".png",   144,144,8,8.0)
				_add_strip(frames,"run_"+dir,   base+"run/run_"+dir+".png",    144,144,8,10.0)
				_add_strip(frames,"attack_"+dir,base+"attack/attack_"+dir+".png",144,144,7,12.0,false)
	return frames

func _add_strip(frames:SpriteFrames, anim_name:String, path:String,
		frame_w:int, frame_h:int, frame_count:int, fps:float, loop:bool=true) -> void:
	var tex = load(path) as Texture2D
	if tex == null:
		push_warning("SpaceportScene: could not load "+path)
		return
	frames.add_animation(anim_name)
	frames.set_animation_speed(anim_name, fps)
	frames.set_animation_loop(anim_name, loop)
	for i in frame_count:
		var atlas = AtlasTexture.new()
		atlas.atlas  = tex
		atlas.region = Rect2(i*frame_w, 0, frame_w, frame_h)
		frames.add_frame(anim_name, atlas)

func _build_boss_frames() -> SpriteFrames:
	var frames = SpriteFrames.new()
	if frames.has_animation("default"): frames.remove_animation("default")
	var base = "res://Characters/minimmo/ZergBoss/"
	for dir in ["s","n","e","w"]:
		_add_strip(frames,"idle_"+dir,  base+"idle/idle_"+dir+".png",   132,132,8,7.0)
		_add_strip(frames,"run_"+dir,   base+"run/run_"+dir+".png",    132,132,8,10.0)
		_add_strip(frames,"attack_"+dir,base+"attack/attack_"+dir+".png",132,132,8,12.0,false)
	return frames

func _build_cyberlord_frames() -> SpriteFrames:
	var frames = SpriteFrames.new()
	if frames.has_animation("default"): frames.remove_animation("default")
	var base = "res://Characters/minimmo/melee2/"
	for dir in ["s","n","e","w"]:
		_add_strip(frames,"idle_"+dir,  base+"idle/idle_"+dir+".png",   144,144,8,7.0)
		_add_strip(frames,"run_"+dir,   base+"run/run_"+dir+".png",    144,144,8,10.0)
		_add_strip(frames,"attack_"+dir,base+"attack/attack_"+dir+".png",144,144,7,12.0,false)
	return frames


# ── HUD (identical structure to BossArenaScene) ───────────────
func _setup_hud(cls: String) -> void:
	_hud       = CanvasLayer.new()
	_hud.layer = 10
	add_child(_hud)

	var vp = get_viewport().get_visible_rect().size

	# Player frame
	_player_frame          = Panel.new()
	_player_frame.size     = Vector2(240, 90)
	_player_frame.position = Vector2(12, 12)
	var pf_sty             = StyleBoxFlat.new()
	pf_sty.bg_color        = Color(0.04, 0.04, 0.08, 0.88)
	pf_sty.border_color    = Color(0.70, 0.74, 0.85, 0.80)
	pf_sty.set_border_width_all(2); pf_sty.set_corner_radius_all(4)
	_player_frame.add_theme_stylebox_override("panel", pf_sty)
	_hud.add_child(_player_frame)
	_player_frame.gui_input.connect(_on_frame_drag)

	_player_name_lbl = Label.new()
	_player_name_lbl.add_theme_font_size_override("font_size", 13)
	_player_name_lbl.add_theme_color_override("font_color", Color(0.85, 0.88, 1.0))
	_player_name_lbl.position = Vector2(10, 6); _player_name_lbl.size = Vector2(220, 20)
	_player_frame.add_child(_player_name_lbl)

	_hp_bar = _make_bar(Color(0.20, 0.78, 0.25), Vector2(10, 28), Vector2(220, 14))
	_mp_bar = _make_bar(Color(0.25, 0.50, 0.95), Vector2(10, 46), Vector2(220, 14))
	_xp_bar = _make_bar(Color(0.90, 0.72, 0.12), Vector2(10, 64), Vector2(220, 8))
	_player_frame.add_child(_hp_bar); _player_frame.add_child(_mp_bar); _player_frame.add_child(_xp_bar)

	_hp_bar_lbl = _make_bar_label(Vector2(10, 27), Vector2(220, 16))
	_mp_bar_lbl = _make_bar_label(Vector2(10, 45), Vector2(220, 16))
	_xp_bar_lbl = _make_bar_label(Vector2(10, 63), Vector2(220, 10))
	_player_frame.add_child(_hp_bar_lbl); _player_frame.add_child(_mp_bar_lbl); _player_frame.add_child(_xp_bar_lbl)

	# Target panel
	_tgt_panel          = Panel.new()
	_tgt_panel.size     = Vector2(200, 56)
	_tgt_panel.position = Vector2(vp.x * 0.5 - 100, 12)
	_tgt_panel.visible  = false
	var tp_sty          = StyleBoxFlat.new()
	tp_sty.bg_color     = Color(0.04, 0.04, 0.08, 0.88)
	tp_sty.border_color = Color(0.80, 0.25, 0.25, 0.80)
	tp_sty.set_border_width_all(2); tp_sty.set_corner_radius_all(4)
	_tgt_panel.add_theme_stylebox_override("panel", tp_sty)
	_hud.add_child(_tgt_panel)

	_tgt_name_lbl = Label.new()
	_tgt_name_lbl.add_theme_font_size_override("font_size", 12)
	_tgt_name_lbl.add_theme_color_override("font_color", Color(1.0, 0.65, 0.65))
	_tgt_name_lbl.position = Vector2(8, 4); _tgt_name_lbl.size = Vector2(184, 18)
	_tgt_panel.add_child(_tgt_name_lbl)

	_tgt_hp_bar = _make_bar(Color(0.85, 0.22, 0.22), Vector2(8, 24), Vector2(184, 12))
	_tgt_panel.add_child(_tgt_hp_bar)
	var tgt_hp_lbl = _make_bar_label(Vector2(8, 23), Vector2(184, 14))
	_tgt_panel.add_child(tgt_hp_lbl)

	# ── Top-right HUD buttons ─────────────────────────────────
	var help_script = load("res://Scripts/HelpWindow.gd")
	var help_win    = CanvasLayer.new()
	help_win.set_script(help_script)
	add_child(help_win)
	help_win.call("init")

	var settings_script = load("res://Scripts/SettingsWindow.gd")
	var settings_win    = CanvasLayer.new()
	settings_win.set_script(settings_script)
	add_child(settings_win)
	settings_win.call("init", self)
	# SettingsWindow owns the tree call — no relay needed

func _make_bar(col: Color, pos: Vector2, sz: Vector2) -> ProgressBar:
	var bar = ProgressBar.new()
	bar.size = sz; bar.position = pos
	bar.min_value = 0.0; bar.max_value = 100.0; bar.value = 100.0
	bar.show_percentage = false
	var fill = StyleBoxFlat.new(); fill.bg_color = col; fill.set_corner_radius_all(2)
	var bg   = StyleBoxFlat.new(); bg.bg_color = Color(0.08,0.08,0.12); bg.set_corner_radius_all(2)
	bar.add_theme_stylebox_override("fill", fill)
	bar.add_theme_stylebox_override("background", bg)
	return bar

func _make_bar_label(pos: Vector2, sz: Vector2) -> Label:
	var l = Label.new()
	l.size = sz; l.position = pos
	l.add_theme_font_size_override("font_size", 10)
	l.add_theme_color_override("font_color", Color(1,1,1,0.88))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _update_hud() -> void:
	if not is_instance_valid(_player): return
	if _player_name_lbl == null: return
	var cls    = _player.get("character_class") as String
	var name_s = _player.get("character_name") as String
	var lvl    = _player.get("level") as int
	_player_name_lbl.text = "%s  Lv.%d  [%s]" % [name_s, lvl, cls.to_upper()]
	var hp = _player.get("hp") as float;     var mhp = _player.get("max_hp") as float
	var mp = _player.get("mp") as float;     var mmp = _player.get("max_mp") as float
	var xp = _player.get("exp_points") as float; var mxp = _player.get("exp_needed") as float
	_hp_bar.max_value = mhp; _hp_bar.value = hp
	_mp_bar.max_value = mmp; _mp_bar.value = mp
	_xp_bar.max_value = mxp; _xp_bar.value = xp
	_hp_bar_lbl.text = "HP  %d / %d" % [int(hp), int(mhp)]
	_mp_bar_lbl.text = "MP  %d / %d" % [int(mp), int(mmp)]
	_xp_bar_lbl.text = "XP  %d / %d" % [int(xp), int(mxp)]
	# Target
	var tgt = _player.get("_current_target")
	if tgt != null and is_instance_valid(tgt):
		_tgt_panel.visible = true
		_tgt_name_lbl.text = tgt.get("enemy_name") if tgt.get("enemy_name") != null else "Target"
		var ehp = tgt.get("hp") as float; var emhp = tgt.get("max_hp") as float
		_tgt_hp_bar.max_value = emhp; _tgt_hp_bar.value = ehp
	else:
		_tgt_panel.visible = false

func _on_frame_drag(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_frame_drag = event.pressed
	elif event is InputEventMouseMotion and _frame_drag:
		var np = _player_frame.position + event.relative
		var vp = get_viewport().get_visible_rect().size
		np.x   = clampf(np.x, 0.0, vp.x - _player_frame.size.x)
		np.y   = clampf(np.y, 0.0, vp.y - _player_frame.size.y)
		_player_frame.position = np

# ── Damage / effect spawners (called by BossArenaPlayer) ──────
func spawn_damage_number(world_pos: Vector2, amount: float, col: Color) -> void:
	var script = load("res://Scripts/DamageNumber.gd")
	var node   = Node2D.new()
	node.set_script(script)
	node.position = world_pos
	add_child(node)
	node.call("init", amount, col)

func spawn_fireball(spawn_pos: Vector2, target: Node, dmg: float) -> void:
	var script = load("res://Scripts/Fireball.gd")
	var fb     = Node2D.new()
	fb.set_script(script)
	fb.position = spawn_pos
	add_child(fb)
	fb.call("init", target, dmg)

func spawn_bullet(spawn_pos: Vector2, target: Node, dmg: float) -> Node:
	var script = load("res://Scripts/Bullet.gd")
	var b      = Node2D.new()
	b.set_script(script)
	b.position = spawn_pos
	add_child(b)
	b.call("init", target, dmg)
	return b

func spawn_melee_hit(world_pos: Vector2, col: Color) -> void:
	var script = load("res://Scripts/MeleeHit.gd")
	var hit    = Node2D.new()
	hit.set_script(script)
	hit.position = world_pos
	add_child(hit)
	hit.call("init", col)

func _on_targetable_removed(_node: Node) -> void:
	pass   # clean up target ref if needed

# ── Ellipse helper ─────────────────────────────────────────────
func _ellipse(center: Vector2, rx: float, ry: float, rot: float, n: int) -> PackedVector2Array:
	var pts   = PackedVector2Array()
	var cos_r = cos(rot); var sin_r = sin(rot)
	for i in n:
		var a  = float(i) / float(n) * TAU
		var lx = cos(a) * rx; var ly = sin(a) * ry
		pts.append(center + Vector2(lx * cos_r - ly * sin_r, lx * sin_r + ly * cos_r))
	return pts
